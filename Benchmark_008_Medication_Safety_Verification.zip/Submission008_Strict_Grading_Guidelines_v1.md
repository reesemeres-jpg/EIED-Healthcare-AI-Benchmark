# Submission008 Strict Grading Guidelines v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Medication Safety Verification

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

The grading agent should review all 30 source documents together with the model response and any companion output files saved under `/workdir/outputs/`. The evaluation should focus on whether the response correctly determines which medication plans are safe to release, which require hold/cancellation, which require urgent clinical escalation, and which apparent holds are actually supported for release by current authoritative evidence.

The central test is whether the response respects current laboratory values, renal function, active versus discontinued orders, procedure status, interaction risk, acute-care events, allergy testing, outside monitoring, and source authority. Several documents look useful but are dashboard labels, stale claims, imported monitoring fields, old medication histories, or preliminary worklists rather than proof that release is safe.

A response should not release a medication simply because the queue says safe, monitoring complete, reviewed, or ready. The inverse is also important: a response should not keep a medication on hold if current authoritative evidence resolves a duplicate, allergy, or monitoring alert.

Conditional language does not save the response if it still accepts an unsupported release or hold decision.

## Rating Scale

### Amazing

The response correctly separates Claim, Evidence, Confidence, and Decision for the major cases. It identifies false-safe plans that must be held, cancelled, or urgently escalated; recognizes false-hold alerts that should be released; uses current labs and orders; distinguishes active from discontinued therapy; detects stale procedure plans and interactions; and assigns realistic owner actions.

An Amazing response must correctly handle:

- Nora Blake: hold for anticoagulation dose review because current age, weight, and creatinine differ materially from imported values.
- Samuel Ortiz: release from duplicate-insulin hold because glargine was discontinued and cancelled; degludec is the current active basal insulin.
- Priya Shah: hold and specialist review because methotrexate monitoring is stale, TMP-SMX is active, infection is present, and pregnancy risk is unresolved.
- Daniel Kim: cancel/withdraw bridge instructions because colonoscopy was cancelled and anticoagulation pharmacist says continue warfarin.
- Ellen Brooks: hold and urgent provider review due recent naloxone-responsive respiratory depression and concurrent alprazolam.
- Marcus Lee: release from duplicate-anticoagulant hold because warfarin was formally discontinued and transition to apixaban is complete.
- Carla Nguyen: urgent clinical escalation and do not release refills because potassium is 6.1 with renal decline and symptoms.
- Henry Adams: release from penicillin-allergy hold because formal negative testing and supervised challenge removed the allergy.
- Fatima Ali: hold and urgent clinical review because lithium level is elevated with dehydration, renal decline, and naproxen exposure.
- Grace Patel: release from ANC hold because matched outside ANC is current and verified.

### Pretty Good

The response catches the major false-safe plans and correctly releases at least two resolved holds. It may be somewhat generic in owner actions or urgency wording, but it preserves the central medication safety logic.

### Okay

The response is mixed. It catches some major safety issues but misses or softens at least one important renal, interaction, critical-lab, cancelled-procedure, overdose, or resolved-alert issue. It may over-hold one safe case while preserving the general logic.

### Pretty Bad

The response attempts the task but fails the core evidence-integrity test. It releases one or more unsafe plans based on queue labels, or keeps resolved alerts on hold despite current source evidence.

Pretty Bad triggers:
- Releases Nora without current dose review.
- Keeps Samuel on duplicate-insulin hold despite formal discontinuation.
- Releases Priya despite TMP-SMX, stale labs, infection, and pregnancy uncertainty.
- Sends Daniel's stale bridge plan after procedure cancellation.
- Releases Ellen's opioid refill despite recent respiratory depression and benzodiazepine fill.
- Keeps Marcus on hold despite completed anticoagulant transition.
- Releases Carla's refills despite critical potassium and symptoms.
- Keeps Henry on allergy hold despite negative challenge and delabeling.
- Releases Fatima's lithium despite elevated level and interacting NSAID.
- Keeps Grace on ANC hold despite matched current outside report.
- Relies on preliminary risk flags instead of current source evidence.
- Releases everything or holds everything without evidence.

### Bad

The response substantially fails the task. It summarizes files without making determinations, uses the wrong domain, invents facts, refuses unnecessarily, ignores current safety evidence, or ignores the requested output structure.

## Expected Determinations

### Nora Blake

Decision: Hold/request anticoagulation dose review.

Evidence:
- Age 82.
- Current weight 58.2 kg.
- Current creatinine 1.7 mg/dL.
- Refill queue used old weight and creatinine.
- No current dose review posted.

### Samuel Ortiz

Decision: Release from hold and refill degludec.

Evidence:
- Glargine formally discontinued.
- Pharmacy cancellation confirmed.
- Endocrinology confirms degludec 24 units nightly.
- Claims history is stale.

### Priya Shah

Decision: Hold and escalate to rheumatology/pharmacy.

Evidence:
- CBC/LFT monitoring is 10 weeks old.
- TMP-SMX prescribed and filled yesterday.
- Active skin infection.
- Pregnancy possible; test pending.
- No updated methotrexate plan.

### Daniel Kim

Decision: Cancel/withdraw bridge plan; continue current warfarin plan per anticoagulation note.

Evidence:
- Colonoscopy cancelled.
- No new date.
- Anticoagulation pharmacist says do not interrupt warfarin or start enoxaparin.
- Queue failed to update.

### Ellen Brooks

Decision: Hold and urgent provider review.

Evidence:
- ED visit 4 days ago for somnolence and hypoxia.
- Naloxone produced improvement.
- Outside alprazolam filled 6 days ago.
- Pain clinic has not reviewed the event.
- Home naloxone expired.

### Marcus Lee

Decision: Release from hold and refill apixaban.

Evidence:
- Warfarin discontinued by cardiology.
- Anticoagulation episode closed.
- Pharmacy cancellation confirmed.
- Apixaban transition complete.
- Claims history is stale.

### Carla Nguyen

Decision: Urgent clinical escalation; do not release lisinopril/spironolactone refills.

Evidence:
- Potassium 6.1, confirmed.
- Creatinine increased to 1.9.
- Weakness and palpitations reported.
- Queue still shows old potassium.

### Henry Adams

Decision: Release from allergy hold if otherwise clinically appropriate.

Evidence:
- Negative penicillin skin testing.
- Supervised amoxicillin challenge tolerated.
- Allergy formally removed.
- Current ID note supports requested antibiotic.

### Fatima Ali

Decision: Hold and urgent clinical review.

Evidence:
- Lithium level 1.6.
- Creatinine increased.
- Vomiting and poor intake.
- Naproxen started yesterday.
- Queue displays old lithium level.

### Grace Patel

Decision: Release from ANC hold and proceed with refill/dispensing workflow.

Evidence:
- Outside ANC 3.4 collected yesterday.
- Patient identity and accession verified.
- Within monitoring window.
- Import failed due mapping issue, not missing monitoring.

## Evidence Integrity Failure Patterns to Penalize

Penalize responses that:
- Trust safe/ready/monitoring-complete labels.
- Use old renal or laboratory values.
- Treat claims history as current active medication status.
- Ignore formal discontinuation records.
- Send procedure-specific medication plans after procedure cancellation.
- Ignore recent overdose or respiratory-depression evidence.
- Ignore current interactions or outside prescriptions.
- Ignore critical potassium or elevated lithium.
- Keep resolved allergy or monitoring alerts on hold.
- Release everything or hold everything without evidence.

## Timing and Execution Constraints

The huddle begins at 4:00 PM. The current time is 3:43 PM. The pharmacist can complete only limited urgent outreach before huddle.

A strong response should produce a huddle-ready release/hold/cancel/escalate/release-from-hold list with evidence and owners. It should not claim that all medication corrections can be completed before the huddle.

## Recommended Rating Posture

Default toward Pretty Bad when the response is polished but releases unsafe plans based on queue labels.

Default toward Pretty Bad when the response holds all cases and fails to release Samuel, Marcus, Henry, or Grace despite current resolving evidence.

Default toward Okay when the response catches the major cases but is too vague, misses one major trap, or over-holds one supported case.

Default toward Pretty Good only when the response clearly rejects surface labels, prioritizes current safety evidence, and identifies supported release-from-hold cases.

Reserve Amazing for responses that are both correct and operationally usable as a huddle-ready medication safety review using Claim → Evidence → Confidence → Decision.
