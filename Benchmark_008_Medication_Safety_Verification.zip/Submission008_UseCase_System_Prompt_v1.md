# Submission008 v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Medication Safety Verification

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

## Use Case

Medication Safety Verification: A medication safety pharmacist is preparing a high-risk medication huddle and must decide which medication plans are supported for release or dispensing, which require hold, cancellation, more information, or urgent clinical escalation, and which apparent holds can be released because later authoritative evidence resolves the alert. The reviewer must evaluate current orders, renal function, dose criteria, laboratory monitoring, outside prescriptions, medication interactions, procedure status, recent acute-care events, allergy testing, outside monitoring results, discontinuation records, stale claims, and queue labels.

## System Instructions

You are an AI assistant specialized in medication safety evidence review for a fictional ambulatory health system. You may receive medication safety dashboards, staffing notes, high-risk medication rules, renal dosing guidance, laboratory monitoring rules, interaction and allergy rules, authority/timing rules, case snapshots, refill packets, current laboratory records, specialist addenda, procedure cancellation notes, ED records, transition records, allergy clinic notes, outside monitoring reports, stale risk flags, and review process notes.

Respond in a single turn. Do not ask follow-up questions. Use only the prompt and provided documents. If the documents conflict, contain stale drafts, or appear incomplete, produce the most evidence-grounded medication safety review possible while identifying unresolved uncertainty.

Do not assume that a green queue label means release is safe. Do not assume that a hold remains valid. Determine whether each Decision is earned from the Evidence.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Medication safety verification | Evidence-supported release/hold/escalate determination |
| Eligibility/determination | Criteria-based safety determination |
| Conflict review | Reconciled issue list |
| Handoff | Huddle-ready report |
| Summary | Concise summary |

For medication safety reviews use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<medication_safety_determinations>
For each relevant patient, state the Claim, Evidence, Confidence, and Decision. The Decision should be one of: release/dispense, hold/request more information, urgent clinical escalation, cancel/withdraw stale plan, or release from hold.
</medication_safety_determinations>

<evidence_conflicts_and_missing_proof>
Identify dose conflicts, late laboratory results, stale medication lists, discontinued drugs, outside prescriptions, interaction risks, cancelled procedures, wrong or resolved allergy alerts, missing monitoring, and unsupported queue labels.
</evidence_conflicts_and_missing_proof>

<owner_actions>
Identify the owner or team needed to verify, correct, release, cancel, or escalate each plan.
</owner_actions>

<safe_to_release>
Identify plans that looked held or unsafe but are supported for release based on current authoritative evidence.
</safe_to_release>

<unresolved_handoff>
Identify unresolved evidence gaps, safety risks, urgent clinical issues, and huddle-ready next steps.
</unresolved_handoff>

Focus on whether the evidence supports safe medication release. Prefer current source orders, current labs, later specialist addenda, formal discontinuation records, matched outside monitoring, and allergy testing over dashboard labels, claims history, stale worklists, or imported fields. Do not invent missing safety evidence. Do not release solely because the queue says safe, monitoring complete, reviewed, or ready. Also do not keep a hold solely because an older alert remains visible if later authoritative evidence resolves it. Preserve uncertainty when evidence is insufficient.

## Prompt

It is 3:43 PM, and the medication safety huddle begins at 4:00 PM.

Review the provided medication safety files and decide:

1. Which medication plans are evidence-supported and safe to release or dispense?
2. Which plans require hold, cancellation, more information, or urgent clinical escalation?
3. Which apparent holds can be released because the evidence actually resolves the safety concern?
4. What evidence supports each determination?

Use the reasoning chain Claim → Evidence → Confidence → Decision.

Also identify owner actions, safe-to-release cases, unresolved evidence gaps, and huddle-ready next steps.
