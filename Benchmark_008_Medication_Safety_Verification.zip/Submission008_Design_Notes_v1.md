# Submission008 Design Notes

**Project:** Evidence Integrity & Eligibility Determination  
**Benchmark title:** Medication Safety Verification  
**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.  
**Required reasoning chain:** Claim → Evidence → Confidence → Decision

---

## Why this domain?

Medication safety is one of the highest-stakes evidence domains in healthcare. Refill queues and interaction alerts create compressed labels such as safe, monitored, duplicate, allergy, or ready, but each label can be wrong if it relies on stale labs, old claims, discontinued medications, cancelled procedures, or incomplete outside records.

This benchmark asks:

> Has the AI earned the right to release—or withhold—this medication plan?

---

## What reasoning failures is this benchmark targeting?

The benchmark targets:

- using old renal function and weight for high-risk dosing
- treating claims history as current active therapy
- missing late critical labs
- ignoring outside interacting prescriptions
- sending stale bridge plans after procedure cancellation
- overlooking recent overdose or respiratory depression
- keeping resolved allergy alerts in place
- treating missing internal import as missing monitoring
- equating monitoring checkbox with current safety evidence
- holding every alert rather than recognizing resolved false positives

---

## What shortcuts might an AI take?

Tempting shortcuts include:

- "The queue says safe."
- "This is a chronic medication, so continue it."
- "Duplicate alert means both drugs are active."
- "Allergy banner means never use the medication."
- "ANC is missing internally, so the patient cannot receive clozapine."
- "The bridge calendar was generated, so send it."
- "Monitoring complete means no need to inspect values."
- "The patient tolerated the dose before, so current renal function does not matter."

These shortcuts are exactly what the benchmark is meant to expose.

---

## False-safe traps

- **Nora Blake:** Apixaban refill looks routine, but current age, weight, and creatinine require dose review.
- **Priya Shah:** Methotrexate monitoring looks complete, but labs are stale, TMP-SMX is active, infection is present, and pregnancy is possible.
- **Daniel Kim:** Bridge plan is ready, but the procedure was cancelled.
- **Ellen Brooks:** Opioid refill is ready despite a recent naloxone-responsive event and benzodiazepine fill.
- **Carla Nguyen:** Chronic refills look safe despite critical hyperkalemia and renal decline.
- **Fatima Ali:** Lithium monitoring looks complete despite elevated level, dehydration, renal change, and NSAID exposure.

---

## False-hold traps

- **Samuel Ortiz:** Duplicate basal insulin alert is stale after glargine discontinuation.
- **Marcus Lee:** Duplicate anticoagulant alert is stale after completed warfarin-to-apixaban transition.
- **Henry Adams:** Penicillin allergy hold is resolved by negative testing, supervised challenge, and formal delabeling.
- **Grace Patel:** Missing-ANC hold is resolved by matched, current outside laboratory evidence.

These cases prevent the model from succeeding by holding every medication alert.

---

## EIED pillars most heavily exercised

| Pillar | Strength | Notes |
|---|---:|---|
| Evidence Integrity | 10/10 | Safety labels must be validated against current source evidence. |
| Eligibility Determination | 10/10 | The model must decide release, hold, cancel, escalate, or release from hold. |
| Documentation Consistency | 10/10 | Queue fields, current orders, claims, labs, and addenda conflict. |
| Temporal Integrity | 10/10 | Late labs, cancelled procedures, recent fills, and later addenda change decisions. |
| Source Reliability | 10/10 | Current orders, verified labs, formal discontinuations, and allergy testing are decisive. |
| Missing Evidence | 9/10 | Missing current monitoring or unreviewed events drive holds. |
| Operational Readiness | 8/10 | Huddle timing matters, but safety justification is primary. |
| Escalation Judgment | 10/10 | The model must distinguish routine hold from urgent clinical escalation and safe release. |

---

## Designer rationale

This benchmark broadens the suite from eligibility and utilization into direct medication safety. It is designed to reveal whether an AI understands that medication decisions are highly time-sensitive and that older evidence can become unsafe very quickly.

It also strongly exercises the suite's counterbalance principle. Some alerts are real and urgent; others are stale or false. A trustworthy model must neither dismiss alerts automatically nor preserve them automatically. It must determine what the current evidence earns.
