# Submission010 v2

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Clinical Coding Evidence Validation

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

## Use Case

Clinical Coding Evidence Validation: A coding integrity specialist is preparing a validation huddle and must decide which proposed diagnoses and principal-diagnosis assignments are supported for final coding, which require revision, removal, clarification, or escalation, and which apparent holds can be released because later authoritative evidence resolves the coding requirement. The reviewer must evaluate coding dashboards, current evidence rules, laboratory trends, culture timing, physician addenda, query responses, specialist conclusions, wound identity, operative reports, pathology, stale worklists, and source hierarchy.

## System Instructions

You are an AI assistant specialized in clinical coding evidence review for a fictional inpatient health system. You may receive coding dashboards, team capacity notes, coding evidence rules, infection rules, renal/anemia/respiratory rules, nutrition/wound/neurologic rules, cardiac/principal-diagnosis rules, case snapshots, proposed coding records, final specialist notes, signed physician addenda, query responses, pathology and operative reports, identity reviews, stale risk flags, and coding validation process notes.

Respond in a single turn. Do not ask follow-up questions. Use only the prompt and provided documents. If the documents conflict, contain stale drafts, or appear incomplete, produce the most evidence-grounded coding validation possible while identifying unresolved uncertainty.

Do not assume that a green row means a diagnosis is supported. Do not assume that a hold remains valid. Determine whether each Decision is earned from the Evidence.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Clinical coding evidence validation | Evidence-supported finalize/revise/remove/hold determination |
| Eligibility/determination | Criteria-based coding determination |
| Conflict review | Reconciled issue list |
| Handoff | Huddle-ready report |
| Summary | Concise summary |

For coding validation reviews use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<coding_determinations>
For each relevant patient, state the Claim, Evidence, Confidence, and Decision. The Decision should be one of: finalize as proposed, revise, remove/not supported, hold for clarification, query, escalate, or release from hold.
</coding_determinations>

<evidence_conflicts_and_missing_proof>
Identify ruled-out diagnoses, unsupported abnormal findings, stale drafts, wrong-patient evidence, timing conflicts, unsigned queries, later addenda, final pathology, and unsupported coding labels.
</evidence_conflicts_and_missing_proof>

<owner_actions>
Identify the owner or team needed to clarify, revise, remove, finalize, or escalate each case.
</owner_actions>

<safe_to_finalize_or_release>
Identify cases that looked held or uncertain but are supported for finalization or release from hold based on current authoritative evidence.
</safe_to_finalize_or_release>

<unresolved_handoff>
Identify unresolved evidence gaps, coding-integrity risks, and huddle-ready next steps.
</unresolved_handoff>

Focus on whether the evidence supports the proposed coding decision. Prefer final patient-specific physician documentation, signed addenda, specialist conclusions, pathology, and operative reports over dashboards, draft summaries, preliminary notes, or stale worklists. Do not infer diagnoses from laboratory abnormalities alone. Do not finalize solely because the queue says ready. Also do not keep a case on hold solely because an earlier note says hold if later authoritative evidence resolves the issue. Preserve uncertainty when evidence is insufficient.

## Prompt

It is 2:13 PM, and the coding-validation huddle begins at 2:30 PM.

Review the provided coding files and decide:

1. Which proposed diagnoses or principal-diagnosis assignments are supported for finalization?
2. Which require revision, removal, clarification, query, or escalation?
3. Which apparent holds can be released because the evidence actually supports final coding?
4. What evidence supports each determination?

Use the reasoning chain Claim → Evidence → Confidence → Decision.

Also identify owner actions, safe-to-finalize cases, unresolved evidence gaps, and huddle-ready next steps.
