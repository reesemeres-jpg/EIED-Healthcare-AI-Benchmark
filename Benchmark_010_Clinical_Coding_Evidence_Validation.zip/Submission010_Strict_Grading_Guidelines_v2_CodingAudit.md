# Submission010 Strict Grading Guidelines v2

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Clinical Coding Evidence Validation

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

The grading agent should review all 30 source documents together with the model response and any companion output files saved under `/workdir/outputs/`. The evaluation should focus on whether the response correctly determines which diagnoses and principal-diagnosis assignments are supported, which must be revised or removed, and which apparent holds are resolved by later authoritative evidence.

The central test is whether the response respects final physician documentation, signed addenda, specialist conclusions, pathology, operative reports, timing, source identity, and clinical consistency. Several documents look useful but are dashboards, draft summaries, abnormal values, copied-forward problem lists, preliminary diagnoses, or stale worklists rather than final coding support.

A response should not finalize a diagnosis because the dashboard says ready, a laboratory value is abnormal, empiric treatment was started, or a draft summary includes the diagnosis. The inverse is also important: a response should not keep a case on hold when later authoritative evidence supports final coding.

Conditional language does not save the response if it still accepts an unsupported finalize or hold decision.

## Rating Scale

### Amazing

The response correctly separates Claim, Evidence, Confidence, and Decision for all major cases. It removes unsupported diagnoses, revises staging or specificity when final evidence differs, releases supported holds, applies final source hierarchy, and assigns realistic owner actions.

An Amazing response must correctly handle:

- Alicia Monroe: remove/not support sepsis; final diagnosis is influenza with dehydration and sepsis ruled out.
- Brian Lee: remove AKI; renal function is at CKD stage 4 baseline.
- Carla Gomez: remove acute blood loss anemia; surgeon attributes anemia to hemodilution.
- David Shah: release from hold and finalize severe protein-calorie malnutrition based on signed provider confirmation.
- Elena Brooks: revise stage 3 to stage 2 and remove reliance on the wrong-patient photo.
- Frank Miller: remove postoperative respiratory failure; ventilation was expected and respiratory failure was ruled out.
- Grace Patel: release from hold and finalize toxic metabolic encephalopathy based on the signed attending addendum.
- Henry Ortiz: remove CAUTI; culture preceded catheter placement and final diagnosis is asymptomatic bacteriuria/no UTI.
- Isabel Chen: remove acute MI; final cardiology and attending documentation support acute nonischemic myocardial injury.
- Jack Turner: release from hold and finalize acute cholecystitis as principal diagnosis based on operative report, pathology, surgeon note, and discharge-summary addendum.

### Pretty Good

The response catches the major unsupported diagnoses and correctly releases at least two supported holds. It may be slightly generic in owner actions or fail to distinguish revision from removal in one secondary case, but it preserves the central coding-integrity logic.

### Okay

The response is mixed. It catches some major unsupported coding but misses or softens at least one important ruled-out diagnosis, wrong-patient source, timing conflict, or final addendum. It may over-hold one supported case while preserving the general logic.

### Pretty Bad

The response attempts the task but fails the core evidence-integrity test. It finalizes one or more unsupported diagnoses or keeps resolved holds in place.

Pretty Bad triggers:
- Finalizes sepsis for Alicia despite final rule-out.
- Finalizes AKI for Brian based on an elevated creatinine at baseline.
- Finalizes acute blood loss anemia for Carla despite hemodilution clarification.
- Keeps David on hold despite signed provider confirmation.
- Finalizes Elena as stage 3 using the wrong-patient photo.
- Finalizes postoperative respiratory failure for Frank despite expected ventilation and rule-out.
- Keeps Grace on hold despite the signed encephalopathy addendum.
- Finalizes CAUTI for Henry despite pre-catheter culture timing and no UTI.
- Finalizes acute MI for Isabel despite final nonischemic injury documentation.
- Keeps Jack on hold despite operative, pathology, surgeon, and discharge-summary confirmation.
- Relies on preliminary risk flags instead of final source evidence.
- Finalizes everything or removes everything without evidence.

### Bad

The response substantially fails the task. It summarizes files without making determinations, uses the wrong domain, invents coding rules, refuses unnecessarily, ignores final documentation, or ignores the requested output structure.

## Expected Determinations

### Alicia Monroe

Decision: Remove/not support sepsis.

Evidence:
- Culture contaminant.
- Repeat cultures and urine culture negative.
- Influenza A positive.
- ID and attending document no bacterial sepsis and sepsis ruled out.

### Brian Lee

Decision: Remove AKI; retain CKD as supported.

Evidence:
- Creatinine 2.1 at admission with baseline 2.0–2.2.
- Discharge creatinine 2.0.
- Nephrology and attending state no AKI.

### Carla Gomez

Decision: Remove acute blood loss anemia.

Evidence:
- Low estimated blood loss.
- No clinical bleeding or transfusion.
- Surgeon attributes hemoglobin drop to hemodilution.
- Acute blood loss anemia explicitly not present.

### David Shah

Decision: Release from hold and finalize severe protein-calorie malnutrition.

Evidence:
- Dietitian criteria support severity.
- Signed attending response confirms diagnosis.
- Diagnosis added to final progress note and discharge summary.

### Elena Brooks

Decision: Revise stage 3 to stage 2.

Evidence:
- Stage 3 photo belongs to another patient.
- Patient-specific wound note supports stage 2.
- Attending confirms stage 2.

### Frank Miller

Decision: Remove postoperative respiratory failure.

Evidence:
- Overnight ventilation was anticipated.
- No unexpected pulmonary complication.
- Extubation occurred as planned.
- Attending says respiratory failure ruled out.

### Grace Patel

Decision: Release from hold and finalize toxic metabolic encephalopathy.

Evidence:
- Signed attending addendum names diagnosis and cause.
- Mental status improved with correction.
- Discharge summary updated.

### Henry Ortiz

Decision: Remove CAUTI and do not finalize UTI.

Evidence:
- Culture collected before Foley placement.
- No urinary symptoms.
- ID documents asymptomatic bacteriuria.
- Attending says CAUTI ruled out.

### Isabel Chen

Decision: Remove acute myocardial infarction.

Evidence:
- Troponin elevation occurred with anemia/tachycardia.
- No ischemic symptoms, ECG changes, or wall-motion abnormality.
- Cardiology documents acute nonischemic myocardial injury.
- Attending removes NSTEMI.

### Jack Turner

Decision: Release from hold and finalize acute cholecystitis as principal diagnosis.

Evidence:
- Operative report supports acute inflammation.
- Pathology confirms acute and chronic cholecystitis.
- Surgeon note names acute cholecystitis.
- Discharge-summary addendum identifies it as principal diagnosis.

## Evidence Integrity Failure Patterns to Penalize

Penalize responses that:
- Trust coding dashboard labels.
- Infer diagnoses from abnormal labs alone.
- Treat empiric treatment as final diagnosis.
- Ignore ruled-out documentation.
- Ignore baseline values.
- Use wrong-patient photos or attachments.
- Treat expected postoperative support as a complication.
- Treat unsigned or pending queries as final support.
- Ignore final pathology, operative reports, and signed addenda.
- Keep stale holds after current documentation resolves them.
- Finalize everything or remove everything without evidence.

## Timing and Execution Constraints

The huddle begins at 2:30 PM. The current time is 2:13 PM. The coding integrity team can update or clarify only a few cases before the huddle.

A strong response should produce a huddle-ready finalize/revise/remove/hold/release list with evidence and owners. It should not claim that every record can be corrected before the huddle.

## Recommended Rating Posture

Default toward Pretty Bad when the response is polished but finalizes unsupported diagnoses based on dashboards, abnormal findings, or draft summaries.

Default toward Pretty Bad when the response keeps all cases on hold and fails to finalize David, Grace, or Jack despite complete current evidence.

Default toward Okay when the response catches the major cases but is too vague, misses one major trap, or over-holds one supported case.

Default toward Pretty Good only when the response clearly rejects unsupported diagnoses, uses final source hierarchy, and identifies supported release-from-hold cases.

Reserve Amazing for responses that are both correct and operationally usable as a huddle-ready coding validation using Claim → Evidence → Confidence → Decision.
