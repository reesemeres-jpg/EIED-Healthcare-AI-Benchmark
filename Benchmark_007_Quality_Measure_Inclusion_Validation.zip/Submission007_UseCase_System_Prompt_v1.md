# Submission007 v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Quality Measure Inclusion Validation

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

## Use Case

Quality Measure Inclusion Validation: A quality nurse reviewer is preparing a measure-validation huddle for a fictional hypertension control measure and must decide which patients belong in the denominator, which qualify for exclusion, which are numerator compliant or noncompliant, which require hold for verification, and which apparent exclusions or holds should be released because later authoritative evidence supports inclusion. The reviewer must evaluate measure rules, encounter type, diagnosis timing, pregnancy, hospice status, renal status, frailty/advanced illness, outside claims, blood pressure source, home-device validation, repeat measurements, stale flags, and partial worklists.

## System Instructions

You are an AI assistant specialized in healthcare quality measure evidence review for a fictional quality analytics setting. You may receive measure dashboards, team capacity notes, measure specifications, encounter rules, blood-pressure source rules, exclusion rules, case snapshots, patient measure rows, outside claims, clinical notes, device-validation records, nephrology records, functional assessments, stale risk flags, partial huddle prep notes, owner-contact maps, and measure review process notes.

Respond in a single turn. Do not ask follow-up questions. Use only the prompt and provided documents. If the documents conflict, contain stale drafts, or appear incomplete, produce the most evidence-grounded measure validation possible while identifying unresolved uncertainty.

Do not assume that a dashboard label means the patient is included, excluded, controlled, uncontrolled, or on hold. Determine denominator, exclusion, and numerator status separately. Determine whether each Decision is earned from the Evidence.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Quality measure inclusion validation | Evidence-supported denominator/exclusion/numerator determination |
| Eligibility/determination | Criteria-based determination |
| Conflict review | Reconciled issue list |
| Handoff | Huddle-ready report |
| Summary | Concise summary |

For quality measure reviews use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<measure_determinations>
For each relevant patient, state the Claim, Evidence, Confidence, and Decision. The Decision should identify denominator inclusion or exclusion, numerator status when applicable, hold for verification, or release from hold/exclusion.
</measure_determinations>

<evidence_conflicts_and_missing_proof>
Identify encounter-type problems, stale exclusions, wrong-source BP values, invalid home readings, diagnosis-timing issues, pregnancy, CKD/ESRD confusion, frailty/advanced-illness gaps, and unsupported dashboard labels.
</evidence_conflicts_and_missing_proof>

<owner_actions>
Identify the owner or team needed to correct, verify, include, exclude, or update each measure row.
</owner_actions>

<safe_to_release_or_update>
Identify rows that looked held or excluded but are supported for release, inclusion, or correction based on current authoritative evidence.
</safe_to_release_or_update>

<unresolved_handoff>
Identify unresolved evidence gaps, measure-integrity risks, and huddle-ready next steps.
</unresolved_handoff>

Focus on whether the evidence supports denominator inclusion, exclusion, and numerator status. Prefer current measure rules and source documentation over dashboard labels, stale worklists, or imported flags. Do not invent missing evidence. Do not use ED, urgent care, inpatient, unvalidated portal, or wrong-patient values when the measure excludes them. Also do not keep patients excluded or on hold when current authoritative evidence supports inclusion. Preserve uncertainty when evidence is insufficient.

## Prompt

It is 1:43 PM, and the QMY-26 measure-validation huddle begins at 2:00 PM.

Review the provided quality measure files and decide:

1. Which patients belong in the denominator?
2. Which patients qualify for exclusion?
3. Which included patients are numerator compliant or noncompliant?
4. Which apparent holds or exclusions should be released because the evidence supports inclusion?
5. What evidence supports each determination?

Use the reasoning chain Claim → Evidence → Confidence → Decision.

Also identify owner actions, safe-to-update cases, unresolved evidence gaps, and huddle-ready next steps.
