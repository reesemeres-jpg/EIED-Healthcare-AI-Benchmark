# Submission007 Design Notes

**Project:** Evidence Integrity & Eligibility Determination  
**Benchmark title:** Quality Measure Inclusion Validation  
**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.  
**Required reasoning chain:** Claim → Evidence → Confidence → Decision

---

## Why this domain?

Quality measure validation is a strong fit for EIED because measure status is built from multiple separate evidence judgments: denominator inclusion, exclusion eligibility, and numerator compliance. Dashboards often compress those into a single label, which creates exactly the kind of evidence shortcut this suite is designed to expose.

This domain also matters operationally because incorrect inclusion or exclusion can distort quality scores, outreach priorities, incentives, and clinical reporting.

The benchmark asks:

> Has the AI earned the right to say this patient belongs in the measure, is excluded, or is compliant?

---

## What reasoning failures is this benchmark targeting?

The benchmark targets:

- treating dashboard status as final
- using non-qualifying encounter types
- using ED, urgent care, inpatient, or unvalidated home BP values
- treating hospice referral as hospice enrollment
- confusing CKD stage 4 with ESRD
- applying stale frailty or advanced-illness exclusions
- ignoring pregnancy exclusion
- failing to use matched outside claims
- rejecting valid repeat BP measurements
- collapsing denominator, exclusion, and numerator into one status

---

## What shortcuts might an AI take?

Tempting shortcuts include:

- "The dashboard says controlled."
- "The patient has renal disease, so exclude."
- "Hospice is mentioned, so exclude."
- "The home BP is lower, so use it."
- "Any encounter counts."
- "If excluded, numerator does not matter, so no need to verify the exclusion."
- "A hold means evidence is missing."
- "Two BP values on one day are conflicting rather than applying the repeat rule."

These shortcuts are exactly what the benchmark is meant to expose.

---

## False-status traps

- **Alice Morgan:** Controlled label is based on ED BP; actual numerator is noncompliant.
- **Carla Diaz:** Included despite pregnancy exclusion.
- **Eva Patel:** Controlled based on unvalidated portal home BP.
- **Frank Wilson:** Excluded as ESRD despite CKD stage 4 only.
- **Isabel Ortiz:** Excluded for frailty/advanced illness based on stale evidence.

---

## False-hold or stale-exclusion traps

- **Benjamin Cole:** Hospice exclusion is unsupported because hospice was declined.
- **David Lee:** Denominator hold is resolved by matched outside hypertension claim.
- **Frank Wilson:** ESRD exclusion should be released.
- **Isabel Ortiz:** Frailty/advanced-illness exclusion should be released.
- **Jack Turner:** Encounter hold is resolved by qualifying outside telehealth.

These cases prevent the model from succeeding by excluding or holding every ambiguous row.

---

## EIED pillars most heavily exercised

| Pillar | Strength | Notes |
|---|---:|---|
| Evidence Integrity | 10/10 | Every measure status must be validated from source evidence. |
| Eligibility Determination | 10/10 | Denominator inclusion, exclusions, and numerator status all require separate decisions. |
| Documentation Consistency | 9/10 | Dashboard rows, claims, clinical notes, and source vitals conflict. |
| Temporal Integrity | 9/10 | Current hospice, current function, and latest qualifying BP matter. |
| Source Reliability | 10/10 | Encounter type, validated device, source claims, and current diagnoses are central. |
| Missing Evidence | 9/10 | Missing enrollment proof, device validation, or qualifying encounters drive holds. |
| Operational Readiness | 8/10 | Huddle timing matters, but evidence-supported classification is primary. |
| Escalation Judgment | 9/10 | The model must decide include, exclude, hold, release, compliant, or noncompliant. |

---

## Designer rationale

This benchmark introduces a different kind of eligibility reasoning: the model must not only decide whether a patient belongs in a group, but also understand that measure membership and measure success are separate. That creates a more structured version of Claim → Evidence → Confidence → Decision.

It also documents an important benchmark-design principle: compressed dashboard labels often hide multiple independent determinations. A trustworthy AI should unpack those determinations rather than inheriting the dashboard's conclusion.
