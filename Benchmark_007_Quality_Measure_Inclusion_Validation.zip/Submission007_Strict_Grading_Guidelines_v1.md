# Submission007 Strict Grading Guidelines v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Quality Measure Inclusion Validation

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

The grading agent should review all 30 source documents together with the model response and any companion output files saved under `/workdir/outputs/`. The evaluation should focus on whether the response correctly determines denominator inclusion, exclusion, numerator status, holds, and release-from-hold or release-from-exclusion decisions.

The central test is whether the response respects measure specifications, encounter type, diagnosis timing, source validity, current exclusion evidence, and numerator rules. Several documents look useful but are dashboards, imported flags, stale worklists, partial huddle notes, wrong-source BP values, or incomplete snapshots rather than proof.

A response should not accept “controlled,” “excluded,” “included,” or “hold” labels without validating the source evidence. The inverse is also important: a response should not keep a patient excluded or on hold if current authoritative evidence supports inclusion.

Conditional language does not save the response if it still accepts an unsupported measure classification.

## Rating Scale

### Amazing

The response correctly separates Claim, Evidence, Confidence, and Decision for the major cases. It distinguishes denominator, exclusion, and numerator status; identifies false-control, false-exclusion, and false-hold rows; applies current measure rules; and assigns realistic owner actions.

An Amazing response must correctly handle:

- Alice Morgan: included in denominator but numerator noncompliant because ED BP does not count; latest qualifying BP is 142/90.
- Benjamin Cole: release from hospice exclusion and include because hospice was declined and no enrollment exists.
- Carla Diaz: exclude due pregnancy during the measurement year.
- David Lee: release from denominator hold and include because matched April outside claim establishes hypertension before June 30 and qualifying encounters exist.
- Eva Patel: included but numerator noncompliant because portal home BP is unvalidated; latest qualifying office BP is 144/88.
- Frank Wilson: release from ESRD exclusion and include because CKD stage 4 is not ESRD; most recent qualifying BP supports control.
- Grace Chen: included and numerator compliant because documented repeat BP 136/84 qualifies.
- Henry Brooks: included and numerator noncompliant; urgent care BP does not count and latest qualifying office BP is 146/92.
- Isabel Ortiz: release from frailty/advanced-illness exclusion and include because current evidence supports neither component; BP supports control.
- Jack Turner: release from encounter hold and include because outside telehealth plus office visit satisfy denominator; numerator compliant based on February office BP 138/88.

### Pretty Good

The response catches the main false labels and correctly releases at least two stale holds/exclusions. It may be slightly generic in owner actions or under-discuss one secondary nuance, but it preserves the measure logic.

### Okay

The response is mixed. It catches some major errors but misses or softens at least one important encounter-type, exclusion, source-validity, or numerator issue. It may correctly include/exclude patients but misclassify one numerator status, or over-hold one supported case.

### Pretty Bad

The response attempts the task but fails the core evidence-integrity test. It accepts one or more dashboard labels as true despite conflicting source evidence, or keeps patients excluded/on hold despite current support for inclusion.

Pretty Bad triggers:
- Calls Alice controlled using ED BP.
- Keeps Benjamin excluded as hospice despite no enrollment.
- Leaves Carla included despite pregnancy.
- Keeps David on hold despite matched outside diagnosis claim.
- Calls Eva controlled using unvalidated portal BP.
- Keeps Frank excluded as ESRD despite CKD stage 4 only.
- Rejects Grace's documented repeat BP.
- Uses Henry's urgent care BP.
- Keeps Isabel excluded based on stale codes.
- Keeps Jack on hold despite qualifying outside telehealth.
- Treats denominator, exclusion, and numerator as one combined status.
- Relies on stale risk flags or partial huddle notes instead of source evidence.
- Includes everyone, excludes everyone, or marks everyone controlled without evidence.

### Bad

The response substantially fails the task. It summarizes files without making determinations, uses the wrong domain, invents rules, refuses unnecessarily, or ignores the requested output structure.

## Expected Determinations

### Alice Morgan

Decision: Include in denominator; numerator noncompliant.

Evidence:
- Hypertension diagnosis and two qualifying visits.
- ED BP 132/84 does not count.
- Most recent qualifying office BP is 142/90.

### Benjamin Cole

Decision: Release from hospice exclusion; include.

Evidence:
- Hospice information visit only.
- Patient declined enrollment.
- No election statement or admission order.
- Current PCP care remains active.

### Carla Diaz

Decision: Exclude due pregnancy.

Evidence:
- Pregnancy occurred during measurement year.
- Measure specification excludes pregnancy at any time during the year.

### David Lee

Decision: Release from hold; include.

Evidence:
- Matched cardiology claim in April includes hypertension diagnosis before June 30.
- Two qualifying internal PCP visits exist.

### Eva Patel

Decision: Include; numerator noncompliant.

Evidence:
- Portal home BP came from unvalidated wrist cuff.
- No technique review.
- Most recent qualifying office BP is 144/88.

### Frank Wilson

Decision: Release from ESRD exclusion; include; numerator compliant.

Evidence:
- CKD stage 4 only.
- No dialysis, transplant, or ESRD.
- Most recent qualifying BP 136/86.

### Grace Chen

Decision: Include; numerator compliant.

Evidence:
- Repeat BP 136/84 after rest using clinic cuff.
- Same-day rule allows documented repeat.

### Henry Brooks

Decision: Include; numerator noncompliant.

Evidence:
- Latest qualifying office BP 146/92.
- Urgent care BP 138/86 does not count.

### Isabel Ortiz

Decision: Release from frailty/advanced-illness exclusion; include; numerator compliant.

Evidence:
- Mild cognitive impairment, not dementia.
- Independent ambulation and ADLs.
- Cancer in remission.
- No current advanced illness/frailty combination.
- Most recent BP 134/82.

### Jack Turner

Decision: Release from encounter hold; include; numerator compliant.

Evidence:
- February PCP office visit plus May synchronous cardiology telehealth satisfy encounter count.
- February office BP 138/88 is most recent qualifying BP.
- Urgent care and unvalidated portal values do not count.

## Evidence Integrity Failure Patterns to Penalize

Penalize responses that:
- Trust dashboard labels.
- Use ED, urgent care, inpatient, or unvalidated portal BP.
- Treat hospice referral as hospice enrollment.
- Ignore pregnancy exclusion.
- Treat CKD stage 4 as ESRD.
- Use stale frailty or advanced illness codes without current support.
- Ignore matched outside claims.
- Reject a valid same-day repeat BP.
- Treat denominator, exclusion, and numerator as one status.
- Keep stale holds or exclusions after current evidence resolves them.

## Timing and Execution Constraints

The huddle begins at 2:00 PM. The current time is 1:43 PM. The quality team can verify or update only a few rows before huddle.

A strong response should produce a huddle-ready inclusion/exclusion/numerator/hold/release list with evidence and owners. It should not claim that all registry corrections can be completed before the huddle.

## Recommended Rating Posture

Default toward Pretty Bad when the response is polished but accepts unsupported dashboard labels.

Default toward Pretty Bad when the response keeps supported patients excluded or on hold.

Default toward Okay when the response catches the major cases but is too vague, misses one major trap, or confuses denominator and numerator logic.

Default toward Pretty Good only when the response clearly separates denominator, exclusion, and numerator decisions and identifies supported release/update cases.

Reserve Amazing for responses that are both correct and operationally usable as a huddle-ready quality measure validation using Claim → Evidence → Confidence → Decision.
