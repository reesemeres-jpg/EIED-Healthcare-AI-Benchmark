# Submission004 Design Notes

**Project:** Evidence Integrity & Eligibility Determination  
**Benchmark title:** Registry Enrollment Audit  
**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.  
**Required reasoning chain:** Claim → Evidence → Confidence → Decision

---

## Why this domain?

Registry outreach is a strong domain for the suite because it looks deceptively simple but depends on evidence integrity. A registry row can say overdue, complete, excluded, or held, but each of those labels may be wrong if outside records, lab identities, procedure quality, high-risk factors, or stale exclusions were not reconciled.

This benchmark tests whether the AI can decide who should actually be contacted, excluded, updated, or reviewed.

The central question is:

> Has the AI earned the right to say this patient belongs in or out of outreach?

---

## What reasoning failures is this benchmark targeting?

This benchmark targets the tendency of AI systems to over-trust registry labels and automated health-maintenance fields.

The main failures include:

- treating a blank internal screening field as proof that screening is absent
- accepting an imported FIT result without checking patient identity
- treating colonoscopy import as complete without reading quality and recommendation
- counting scheduled procedures as completed screening
- ignoring high-risk family history that changes the pathway
- treating stale hospice or colectomy exclusions as authoritative
- failing to distinguish total colectomy from segmental colectomy
- keeping holds in place after final outside reports or lab-interface evidence resolves them

The benchmark asks the model to audit registry truth, not merely repeat registry status.

---

## What shortcuts might an AI take?

Tempting shortcuts include:

- "The registry says overdue, so send outreach."
- "The registry says complete, so suppress outreach."
- "The registry says hospice or colectomy, so exclude."
- "A scheduled colonoscopy means screening is handled."
- "An imported FIT result means the patient completed FIT."
- "Any colonoscopy counts for 10 years."
- "A referral hold should stay until someone manually closes the referral."
- "Same household is close enough for lab matching."

Those shortcuts are exactly what this benchmark is meant to expose.

---

## False-clean or false-status traps

These rows look eligible, complete, or excluded but require correction:

- **Janet Cole:** Outreach eligible in registry, but matched outside colonoscopy supports current screening completion.
- **Marcus Reed:** Screening complete by imported FIT, but specimen identity suggests the result belongs to spouse.
- **Elaine Moore:** Outreach eligible, but total proctocolectomy supports exclusion.
- **Rafael Cruz:** Routine FIT outreach eligible, but high-risk family history requires clinician/GI pathway.
- **Lori Bennett:** Colonoscopy complete in registry, but report was incomplete with poor prep and repeat recommended.
- **Samir Patel:** Colonoscopy scheduled, but scheduled is not completed screening.

---

## False-hold or stale-exclusion traps

These rows look blocked or excluded but should be released or corrected:

- **Michael Dunn:** FIT result missing in registry, but source lab shows matched negative FIT and import failure.
- **Priya Nair:** Hospice exclusion is stale/misassigned; current care status supports preventive screening.
- **Thomas Reed:** Colectomy exclusion is wrong because surgery was segmental and colon remains.
- **Grace Hill:** GI referral hold is stale because final outside colonoscopy report is available.

These cases prevent the model from succeeding by simply holding or excluding messy registry rows.

---

## EIED pillars most heavily exercised

| Pillar | Strength | Notes |
|---|---:|---|
| Evidence Integrity | 10/10 | Registry labels must be validated against source documentation. |
| Eligibility Determination | 10/10 | The model must decide outreach, suppress, exclude, hold, defer, or release. |
| Documentation Consistency | 9/10 | Registry rows, outside reports, lab records, surgical history, and PCP notes conflict. |
| Temporal Integrity | 9/10 | Stale holds, imported fields, final reports, and current care status alter decisions. |
| Source Reliability | 10/10 | Source reports, identity-matched labs, surgery records, and PCP/GI notes outweigh registry labels. |
| Missing Evidence | 9/10 | Missing screening proof, invalid imports, incomplete procedures, and unlinked reports drive decisions. |
| Operational Readiness | 8/10 | Outreach huddle timing matters, but evidence-supported eligibility is the core. |
| Escalation Judgment | 10/10 | The model must determine outreach, suppression, exclusion, release, hold, defer, or clinician escalation. |

---

## Designer rationale

This benchmark expands the suite into population health and registry quality, where bad evidence reasoning can cause both over-outreach and under-outreach. It is valuable because registry errors often look administrative, but they affect patient experience, quality reporting, and care gaps.

It also adds a strong identity-matching dimension. The model must understand that present evidence is not automatically authoritative; the right report has to belong to the right patient, at the right time, with enough quality to support the registry decision.
