# Submission004 Strict Grading Guidelines v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Registry Enrollment Audit

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

The grading agent should review all 30 source documents together with the model response and any companion output files saved under `/workdir/outputs/`. The evaluation should focus on whether the response correctly determines which registry rows are eligible for outreach, which should be suppressed/updated complete, which should be excluded, which require hold or escalation, and which apparent holds or exclusions are actually supported for release or correction by current authoritative evidence.

The central test is whether the response respects evidence provenance, current registry rules, source identity matching, screening quality, exclusion validity, high-risk pathway logic, and final source evidence. Several documents look useful but are registry labels, dashboard statuses, imported fields, stale risk flags, partial huddle prep notes, or incomplete snapshots rather than proof that outreach eligibility, completion, exclusion, or hold status is supported.

A response should not outreach someone simply because the registry says overdue. A response should not suppress outreach simply because the registry says complete. A response should not exclude or hold someone simply because a stale label says hospice, colectomy, GI referral pending, or result missing.

Conditional language does not save the response if it still accepts an unsupported outreach, suppression, exclusion, or hold decision.

## Rating Scale

### Amazing

The response correctly separates Claim, Evidence, Confidence, and Decision for the major cases. It identifies false-outreach rows that should be suppressed/excluded/escalated, recognizes false-complete rows that should return to outreach or review, releases stale holds/exclusions when evidence supports correction, and assigns realistic owner actions.

An Amazing response must correctly handle the major traps:

- Janet Cole: suppress outreach/update complete because matched outside colonoscopy supports current screening.
- Marcus Reed: do not suppress outreach as complete; FIT result likely belongs to spouse and does not support Marcus's screening completion.
- Elaine Moore: exclude from routine CRC screening registry because total proctocolectomy/no remaining colon is documented.
- Rafael Cruz: do not send routine average-risk FIT outreach; escalate to clinician/GI pathway due first-degree relative colon cancer at 48.
- Lori Bennett: do not treat colonoscopy as complete 10-year screening; report was incomplete/poor prep with repeat recommended within 1 year.
- Michael Dunn: release from missing-result hold/update complete because matched FIT result exists and registry import failed.
- Priya Nair: release from stale hospice exclusion and consider outreach because current records do not support hospice exclusion.
- Thomas Reed: release from colectomy exclusion and consider outreach because surgery was segmental and colon remains.
- Grace Hill: release from GI referral hold/update complete because final outside colonoscopy report supports screening completion.
- Samir Patel: do not count scheduled colonoscopy as completed screening; may defer duplicate outreach until procedure date but cannot update complete.

### Pretty Good

The response catches the main false labels and correctly releases at least two stale holds/exclusions. It may be somewhat generic in owners, may under-discuss one secondary row, or may be slightly imperfect in outreach/defer phrasing, but it preserves the central evidence-integrity and registry eligibility logic.

### Okay

The response is mixed. It catches some major registry errors but misses or softens at least one important identity, exclusion, completion-quality, or high-risk pathway issue. It may over-trust one registry label or over-hold one stale exclusion while preserving the general logic.

### Pretty Bad

The response attempts the task but fails the core evidence-integrity test. It accepts one or more registry labels as true despite conflicting or missing evidence, or it keeps patients on hold/excluded despite source evidence supporting release/correction.

Pretty Bad triggers:
- Sends Janet outreach despite matched outside colonoscopy.
- Suppresses Marcus outreach as complete despite specimen mismatch.
- Sends Elaine routine outreach despite total proctocolectomy.
- Sends Rafael routine FIT outreach despite high-risk family history.
- Treats Lori's colonoscopy as a normal complete 10-year screening despite poor prep/incomplete exam.
- Keeps Michael on missing-result hold despite matched negative FIT result.
- Keeps Priya excluded as hospice despite current records contradicting the label.
- Keeps Thomas excluded due colectomy despite segmental-only colectomy.
- Keeps Grace on GI referral hold despite final outside colonoscopy report.
- Counts Samir's scheduled colonoscopy as completed screening.
- Relies on stale risk flags or partial huddle notes instead of source documents.
- Outreachs everyone or suppresses everyone without evidence.

### Bad

The response substantially fails the task. It summarizes files without making determinations, uses the wrong domain, invents facts, refuses unnecessarily, ignores registry rules, or produces classifications that are mostly unsupported.

Bad is appropriate if the response:
- Does not identify major registry-label failures.
- Does not identify stale hold/exclusion release cases.
- Treats the task as generic patient messaging rather than registry eligibility validation.
- Makes up screening rules not present in the documents.
- Ignores the requested output structure.

## Expected Determinations

### Janet Cole — Outside Colonoscopy Match

Expected decision: Suppress outreach/update complete.

Evidence:
- Registry says outreach eligible due blank internal field.
- Outside report under Janet Colee matches DOB and address.
- Colonoscopy 18 months ago reached cecum, good prep, no polyps, repeat in 10 years.
- HIE identity note links the near-match surname to Janet Cole.

Owner action:
HIE specialist/registry nurse should link outside report and update screening status.

### Marcus Reed — FIT Identity Mismatch

Expected decision: Hold completion status; do not suppress as complete. Outreach/recollection or verification needed.

Evidence:
- Registry says negative FIT imported.
- Specimen name is Marcia Reed.
- Specimen DOB does not match Marcus.
- Same household only.
- Marcus's FIT order remains open.

Owner action:
Lab interface analyst should correct misrouted result; outreach coordinator should obtain valid FIT or outreach as appropriate.

### Elaine Moore — Total Colectomy Exclusion

Expected decision: Exclude from routine CRC screening registry outreach.

Evidence:
- Total proctocolectomy with end ileostomy.
- GI note says no remaining colon or rectum.
- PCP note says CRC outreach not applicable.
- Registry surgical-history field is blank.

Owner action:
Registry nurse/PCP should update exclusion.

### Rafael Cruz — High-Risk Family History

Expected decision: Hold routine FIT outreach and escalate to clinician/GI pathway.

Evidence:
- Father diagnosed with colon cancer at age 48.
- Patient asks about colonoscopy rather than stool test.
- PCP note says family history may require risk-based plan.
- Routine average-risk FIT template remains queued.

Owner action:
PCP/GI referral coordinator should determine risk-based screening plan.

### Lori Bennett — Incomplete/Poor Prep Colonoscopy

Expected decision: Do not treat as complete; outreach or GI follow-up needed for repeat.

Evidence:
- Registry imported colonoscopy as complete.
- Report says cecum not reached and prep poor in right colon.
- Recommendation was repeat colonoscopy within 1 year.
- Procedure was 14 months ago and no repeat found.

Owner action:
PCP/GI referral coordinator should arrange repeat and update registry interval.

### Michael Dunn — False-Hold / FIT Result Exists

Expected decision: Release from hold/update complete.

Evidence:
- Registry says FIT result missing.
- Source lab record shows negative FIT 6 days ago.
- Specimen name/DOB match.
- Accession number matches order.
- Lab analyst says registry import failed due mapping error.

Owner action:
Lab interface analyst/registry nurse should correct import and update completion.

### Priya Nair — False Hospice Exclusion

Expected decision: Release from hospice exclusion and consider outreach if otherwise due.

Evidence:
- Hospice exclusion label came from imported flag.
- No hospice enrollment order found.
- Home health summary says not enrolled in hospice.
- PCP annual visit documents preventive care and patient prefers FIT.
- Hospice label appears copied from discontinued referral order.

Owner action:
PCP/registry nurse should remove stale exclusion and queue appropriate screening.

### Thomas Reed — False Colectomy Exclusion

Expected decision: Release from colectomy exclusion and consider outreach.

Evidence:
- Registry says colectomy exclusion.
- Surgery was segmental sigmoid colectomy for diverticulitis.
- Colon and rectum otherwise remain.
- GI note says routine CRC screening should continue.
- No colonoscopy in last 10 years.

Owner action:
HIM/registry nurse should correct surgery-based exclusion and restore health maintenance.

### Grace Hill — False Referral Hold / Colonoscopy Complete

Expected decision: Release from GI referral hold/update complete.

Evidence:
- Referral hold says pending GI referral.
- Outside GI final report received.
- Colonoscopy 3 weeks ago, identifiers match, cecum reached, adequate prep.
- Findings support 10-year recommendation.
- Referral status remained open because report was not linked.

Owner action:
GI referral coordinator/registry nurse should link report and update registry.

### Samir Patel — Scheduled But Not Completed

Expected decision: Not complete. Defer duplicate outreach or leave pending per workflow, but do not update as screened.

Evidence:
- Colonoscopy scheduled next week.
- No completed report.
- Prior scheduled procedures were cancelled.
- Screening interval criteria say scheduled colonoscopy does not count as completed screening.

Owner action:
Outreach coordinator may defer until procedure date, then verify completion.

## Evidence Integrity Failure Patterns to Penalize

Penalize responses that:
- Trust registry labels.
- Treat internal blankness as proof no outside screening exists.
- Treat imported FIT as valid without patient identity.
- Treat scheduled colonoscopy as completed screening.
- Treat ordered FIT kit as completed screening.
- Treat poor-prep or incomplete colonoscopy as a normal 10-year interval.
- Exclude total and segmental colectomy the same way.
- Treat stale hospice labels as current without verification.
- Send routine average-risk outreach despite high-risk family history.
- Keep stale holds despite final outside report or lab result.
- Outreach everyone, suppress everyone, or exclude everyone without evidence.

## Timing and Execution Constraints

The huddle begins at 9:00 AM. The current time is 8:43 AM. The registry nurse has limited time and can update or verify only a few rows before huddle.

A strong response should produce a huddle-ready outreach/suppress/exclude/hold/release list with evidence and owners. It should not claim that all identity, lab-interface, HIE, referral, and registry corrections can be completed before the huddle.

## Recommended Rating Posture

Default toward Pretty Bad when the response is polished but accepts unsupported registry labels for major traps.

Default toward Pretty Bad when the response holds or excludes patients despite current source evidence supporting release/correction.

Default toward Okay when the response catches the major cases but is too vague, misses one major trap, or over-holds one stale label.

Default toward Pretty Good only when the response clearly rejects surface labels, applies current registry rules, and identifies supported release/update cases.

Reserve Amazing for responses that are both correct and operationally usable as a huddle-ready registry audit using Claim → Evidence → Confidence → Decision.
