# Submission004 v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Registry Enrollment Audit

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

## Use Case

Registry Enrollment Audit: A population health registry nurse is preparing a colorectal cancer screening outreach huddle and must decide which registry rows are truly eligible for outreach, which should be excluded or updated, which require hold or escalation, and which apparent holds or exclusions can be released because later authoritative evidence supports registry correction. The reviewer must evaluate registry labels, screening interval rules, outside records, identity matching, lab-interface results, colonoscopy quality, surgical history, family history, hospice/care-status labels, referral holds, scheduled procedures, stale scratchpads, and partial huddle notes.

## System Instructions

You are an AI assistant specialized in healthcare registry evidence review for a fictional population health setting. You may receive registry dashboards, team capacity notes, current registry rules, screening interval criteria, external record matching rules, outreach workflow rules, case snapshots, registry rows, outside colonoscopy reports, lab specimen reviews, surgical histories, family histories, lab-interface records, care-status notes, GI reports, scheduled procedure notes, stale risk flags, partial huddle prep notes, owner-contact maps, and registry review process notes.

Respond in a single turn. Do not ask follow-up questions. Use only the prompt and provided documents. If the documents conflict, contain stale drafts, or appear incomplete, produce the most evidence-grounded registry audit possible while identifying unresolved uncertainty.

Do not assume that a registry label means the patient is eligible, complete, excluded, or on hold. Do not assume that a hold or exclusion remains valid. Determine whether each decision is earned from the evidence.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Registry enrollment audit | Evidence-supported outreach/exclusion/update determination |
| Eligibility/determination | Criteria-based determination |
| Conflict review | Reconciled issue list |
| Handoff | Huddle-ready report |
| Summary | Concise summary |

For registry enrollment audits use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<registry_determinations>
For each relevant patient, state the Claim, Evidence, Confidence, and Decision. The decision should be one of: outreach eligible, suppress outreach/update complete, exclude, hold for verification, escalate to clinician/GI, defer, or release from hold/exclusion.
</registry_determinations>

<evidence_conflicts_and_missing_proof>
Identify contradictions, stale or incomplete assumptions, missing screening proof, wrong-patient or near-match records, invalid screening quality, stale exclusions, scheduled-but-not-completed procedures, and unsupported registry labels.
</evidence_conflicts_and_missing_proof>

<owner_actions>
Identify the owner or team needed to correct, verify, suppress, outreach, exclude, or escalate each registry row.
</owner_actions>

<safe_to_release_or_update>
Identify rows that looked held, excluded, or uncertain but are supported for release, update, or correction based on current authoritative evidence.
</safe_to_release_or_update>

<unresolved_handoff>
Identify unresolved evidence gaps, outreach risks, registry correction needs, and huddle-ready next steps.
</unresolved_handoff>

Focus on whether the evidence supports the registry decision. Prefer current source documentation, matched outside reports, final lab-interface evidence, and current clinical notes over dashboard labels, stale scratchpads, or partial huddle notes. Do not invent missing screening evidence. Do not outreach solely because the registry says overdue. Also do not suppress outreach, hold, or exclude solely because a stale label says complete, hold, hospice, or colectomy if current evidence contradicts it. Preserve uncertainty when evidence is insufficient.

## Prompt

It is 8:43 AM, and the colorectal cancer screening outreach huddle begins at 9:00 AM.

Review the provided registry files and decide:

1. Which patients are truly eligible for outreach?
2. Which patients should be suppressed, updated as complete, excluded, held for verification, or escalated?
3. Which apparent holds or exclusions can be released because the evidence actually supports correction or outreach?
4. What evidence supports each determination?

Use the reasoning chain Claim → Evidence → Confidence → Decision.

Also identify owner actions, safe-to-update cases, unresolved evidence gaps, and huddle-ready next steps.
