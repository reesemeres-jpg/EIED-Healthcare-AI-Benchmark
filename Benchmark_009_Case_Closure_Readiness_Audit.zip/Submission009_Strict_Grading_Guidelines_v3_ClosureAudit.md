# Submission009 Strict Grading Guidelines v3

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Case Closure Readiness Audit

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

The grading agent should review all 30 source documents together with the model response and any companion output files saved under `/workdir/outputs/`. The evaluation should focus on whether the response correctly determines which cases are genuinely ready to close, which must remain open or be escalated, and which apparent holds are actually supported for closure by later authoritative evidence.

The central test is whether the response respects communication completion, corrective-action verification, source identity, final outside or vendor reports, referral outcomes, privacy obligations, and current owner action. Several documents look useful but are dashboard labels, checkboxes, signed summaries, preliminary notes, or planned actions rather than proof of closure readiness.

A response should not close a case simply because the dashboard says ready, the summary is signed, a checkbox is complete, or an action was initiated. The inverse is also important: a response should not keep a case open if later authoritative evidence fully resolves the closure requirement.

Conditional language does not save the response if it still accepts an unsupported close or hold decision.

## Rating Scale

### Amazing

The response correctly separates Claim, Evidence, Confidence, and Decision for the major cases. It identifies false-ready cases that must remain open or be escalated, recognizes false-hold cases that should close, distinguishes attempted from completed communication, verifies corrective actions and identity, applies source hierarchy, and assigns realistic owners.

An Amazing response must correctly handle:

- Alicia Hart: keep open because staff education corrective action is incomplete and not formally transferred.
- Brian Knox: keep open because attempted calls and an unopened portal message do not prove patient communication.
- Carla Ruiz: release from duplicate-complaint hold and close because records were merged, a final response was delivered, and the patient acknowledged resolution.
- David Kim: release from referral hold and close because a matched outside cardiology report and patient confirmation resolve the outcome.
- Elena Moore: keep open and escalate because closure relied on a wrong-patient photo and current evidence suggests a hospital-acquired injury.
- Frank Bell: keep open and urgently escalate because direct patient communication and ED evaluation are not confirmed after a critical potassium result.
- Grace Patel: release from vendor hold and close because the final technical report, local inspection, education verification, and safety acceptance are complete.
- Henry Adams: keep open and escalate to the privacy officer because unauthorized access cannot be ruled out and the breach assessment is incomplete.
- Isabel Ortiz: release from communication hold and close because direct conversation, teach-back, a follow-up order, a reminder, and a signed addendum are complete.
- Jack Turner: keep open because fleet inspection and staff education are incomplete and not formally transferred.

### Pretty Good

The response catches the main false-ready cases and correctly closes at least two resolved hold cases. It may be somewhat generic in owner actions or slightly imperfect in urgency phrasing, but it preserves the core closure-readiness logic.

### Okay

The response is mixed. It catches some major closure failures but misses or softens at least one important communication, identity, corrective-action, privacy, or later-report issue. It may over-hold one resolved case while preserving the general logic.

### Pretty Bad

The response attempts the task but fails the core evidence-integrity test. It closes one or more cases based on status labels or keeps resolved cases open despite authoritative evidence.

Pretty Bad triggers:
- Closes Alicia despite incomplete education.
- Closes Brian based on attempted communication.
- Keeps Carla open despite the consolidated response and patient acknowledgment.
- Keeps David open despite the matched outside specialist outcome.
- Closes Elena despite the wrong-patient photo.
- Closes Frank without proof that he received critical-result instructions.
- Keeps Grace open despite the final vendor report and verified actions.
- Closes Henry despite the incomplete privacy assessment.
- Keeps Isabel open despite direct communication and follow-up completion.
- Closes Jack despite incomplete inspections and education.
- Relies on preliminary risk flags instead of current source evidence.
- Closes everything or holds everything without evidence.

### Bad

The response substantially fails the task. It summarizes the files without making determinations, uses the wrong domain, invents facts, refuses unnecessarily, ignores closure criteria, or ignores the requested output structure.

## Expected Determinations

### Alicia Hart

Decision: Keep open/hold.

Evidence:
- Only 14 of 22 assigned staff completed education.
- Six staff remain overdue.
- No formal accepted transfer with owner and due date is documented.
- The closure summary predates the completion report.

### Brian Knox

Decision: Keep open/hold.

Evidence:
- Calls reached voicemail.
- The portal message was not opened.
- No bedside disclosure note exists.
- Direct patient communication is not confirmed.

### Carla Ruiz

Decision: Release from hold and close.

Evidence:
- Duplicate cases were linked and merged.
- The final response addressed the actual concern.
- A confirmed neurology appointment was provided.
- The patient acknowledged receipt and said the issue was resolved.
- The manager signed the closure addendum.

### David Kim

Decision: Release from hold and close.

Evidence:
- The outside cardiology report matches the patient.
- The visit occurred and addressed the referral concern.
- The referral coordinator linked the report.
- The patient confirmed that the access issue was resolved.

### Elena Moore

Decision: Keep open and escalate.

Evidence:
- The attached photo belongs to another patient.
- The photo predates Elena's admission.
- Elena's admission assessment showed intact skin.
- The first injury documentation occurred on hospital day 3.
- The closure summary relied on wrong-patient evidence.

### Frank Bell

Decision: Keep open and urgently escalate.

Evidence:
- No direct patient contact is documented.
- The spouse only said the message would be relayed.
- No portal message was sent.
- No ED encounter is found.
- The template note does not identify who received the instruction.

### Grace Patel

Decision: Release from hold and close.

Evidence:
- The final vendor report found no device defect.
- The alarm matched an upstream occlusion.
- Biomedical inspection was completed.
- Education was completed and verified.
- The patient safety specialist accepted the findings and signed the addendum.

### Henry Adams

Decision: Keep open and escalate to the privacy officer.

Evidence:
- Another patient handled protected information.
- Unauthorized access cannot be ruled out.
- The final breach assessment is incomplete.
- The disclosure log and notification decision memorandum are absent.

### Isabel Ortiz

Decision: Release from hold and close.

Evidence:
- A direct clinician-to-patient conversation is documented.
- The delayed routing, finding, follow-up, and precautions were discussed.
- The patient repeated the plan accurately.
- The follow-up order and reminder were placed.
- A signed addendum and patient-relations note are present.

### Jack Turner

Decision: Keep open/hold.

Evidence:
- Only 18 of 32 stretchers were inspected.
- The staff reminder was not distributed.
- No accepted transfer with owner and due date is documented.
- The safety specialist explicitly says not to close.

## Evidence Integrity Failure Patterns to Penalize

Penalize responses that:
- Trust ready-to-close dashboard labels.
- Treat checkboxes as proof.
- Treat voicemail attempts as completed communication.
- Treat proposed or initiated actions as completed actions.
- Ignore wrong-patient attachments.
- Ignore later final reports that resolve holds.
- Ignore unresolved privacy obligations.
- Keep stale holds after complete closure evidence posts.
- Close everything or hold everything without evidence.

## Timing and Execution Constraints

The huddle begins at 4:30 PM. The current time is 4:13 PM. The case-resolution nurse can verify or update only a few cases before the huddle.

A strong response should produce a huddle-ready close/hold/escalate/release list with evidence and owners. It should not claim that every unresolved action can be completed before the huddle.

## Recommended Rating Posture

Default toward Pretty Bad when the response is polished but closes unsupported cases based on labels or checkboxes.

Default toward Pretty Bad when the response keeps all cases open and fails to close Carla, David, Grace, or Isabel despite complete current evidence.

Default toward Okay when the response catches the major cases but is too vague, misses one major trap, or over-holds one supported closure.

Default toward Pretty Good only when the response clearly rejects surface labels and identifies supported close and release-from-hold cases.

Reserve Amazing for responses that are both correct and operationally usable as a huddle-ready closure-readiness audit using Claim → Evidence → Confidence → Decision.
