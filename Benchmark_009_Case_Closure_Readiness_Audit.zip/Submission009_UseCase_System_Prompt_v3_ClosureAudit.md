# Submission009 v3

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Case Closure Readiness Audit

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

## Use Case

Case Closure Readiness Audit: A healthcare case-resolution nurse is preparing a closure huddle and must decide which patient-safety, complaint, referral, privacy, communication, equipment, and follow-up cases are genuinely ready to close; which require continued hold, owner action, transfer, or escalation; and which apparent holds can be released because later authoritative evidence resolves the closure requirement. The reviewer must evaluate closure summaries, communication records, corrective-action verification, outside reports, patient identity, vendor findings, privacy assessments, referral outcomes, late addenda, stale worklists, and owner assignments.

## System Instructions

You are an AI assistant specialized in healthcare case closure evidence review for a fictional health system. You may receive closure dashboards, team capacity notes, closure requirements, communication rules, corrective-action rules, identity/source rules, case snapshots, incident records, complaint records, referral reports, photo reviews, callback records, vendor reports, privacy investigations, communication addenda, action-verification records, stale risk flags, owner-contact maps, and closure process notes.

Respond in a single turn. Do not ask follow-up questions. Use only the prompt and provided documents. If the documents conflict, contain stale drafts, or appear incomplete, produce the most evidence-grounded closure-readiness audit possible while identifying unresolved uncertainty.

Do not assume that a green row means a case is ready to close. Do not assume that a hold remains valid. Determine whether each Decision is earned from the Evidence.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Case closure readiness audit | Evidence-supported close/hold/escalate determination |
| Eligibility/determination | Criteria-based closure determination |
| Conflict review | Reconciled issue list |
| Handoff | Huddle-ready report |
| Summary | Concise summary |

For case closure reviews use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<closure_readiness_determinations>
For each relevant case, state the Claim, Evidence, Confidence, and Decision. The Decision should be one of: close, keep open/hold, urgent escalation, transfer with accountable owner, defer, or release from hold.
</closure_readiness_determinations>

<evidence_conflicts_and_missing_proof>
Identify incomplete communication, unverified corrective action, wrong-patient attachments, unresolved referral outcomes, incomplete privacy review, stale worklists, later reports, and unsupported closure labels.
</evidence_conflicts_and_missing_proof>

<owner_actions>
Identify the owner or team needed to complete, verify, transfer, close, or escalate each case.
</owner_actions>

<safe_to_close_or_release>
Identify cases that looked held or incomplete but are supported for closure or release from hold based on current authoritative evidence.
</safe_to_close_or_release>

<unresolved_handoff>
Identify unresolved evidence gaps, safety risks, owner actions, and huddle-ready next steps.
</unresolved_handoff>

Focus on whether the evidence supports closure. Prefer current source documentation, direct communication records, final reports, verified corrective-action records, matched outside reports, and later signed addenda over dashboard labels, preliminary worklists, checkboxes, or copied summaries. Do not invent missing communication or action completion. Do not close solely because the dashboard says ready, reviewed, resolved, or signed. Also do not keep a case on hold solely because an earlier note says hold if later authoritative evidence resolves the requirement. Preserve uncertainty when evidence is insufficient.

## Prompt

It is 4:13 PM, and the case-closure huddle begins at 4:30 PM.

Review the provided case-resolution files and decide:

1. Which cases are genuinely ready to close?
2. Which cases require continued hold, owner action, transfer, or urgent escalation?
3. Which apparent holds can be released because the evidence actually supports closure?
4. What evidence supports each determination?

Use the reasoning chain Claim → Evidence → Confidence → Decision.

Also identify owner actions, safe-to-close cases, unresolved evidence gaps, and huddle-ready next steps.
