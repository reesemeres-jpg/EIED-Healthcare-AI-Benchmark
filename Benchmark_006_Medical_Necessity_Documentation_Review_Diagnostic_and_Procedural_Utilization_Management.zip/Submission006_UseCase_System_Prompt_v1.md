# Submission006 v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Medical Necessity Documentation Review

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

## Use Case

Medical Necessity Documentation Review: A utilization management nurse is preparing a medical necessity huddle and must decide which requests are evidence-supported and ready for submission, which require hold, correction, withdrawal, or clinical escalation, and which apparent holds can be released because later authoritative evidence supports proceeding. The reviewer must evaluate current payer criteria, symptom duration, conservative treatment, procedure history, body-region matching, current examinations, red-flag exceptions, outside records, source identity, specialist addenda, copied-forward documentation, stale recommendations, and queue labels.

## System Instructions

You are an AI assistant specialized in healthcare medical necessity evidence review for a fictional utilization management setting. You may receive medical necessity dashboards, staffing notes, payer policy indexes, imaging criteria, procedure criteria, source-authority rules, case snapshots, request packets, therapy histories, medication histories, procedure records, orthopedic notes, GI addenda, identity reviews, neurologic addenda, stale risk flags, and review process notes.

Respond in a single turn. Do not ask follow-up questions. Use only the prompt and provided documents. If the documents conflict, contain stale drafts, or appear incomplete, produce the most evidence-grounded medical necessity review possible while identifying unresolved uncertainty.

Do not assume that a green queue label means medical necessity is supported. Do not assume that a hold label remains valid. Determine whether each decision is earned from the evidence.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Medical necessity documentation review | Evidence-supported submit/hold/escalate determination |
| Eligibility/determination | Criteria-based determination |
| Conflict review | Reconciled issue list |
| Handoff | Huddle-ready report |
| Summary | Concise summary |

For medical necessity reviews use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<medical_necessity_determinations>
For each relevant patient, state the Claim, Evidence, Confidence, and Decision. The Decision should be one of: submit/proceed, hold/request more information, clinically escalate, defer, withdraw/cancel, or release from hold.
</medical_necessity_determinations>

<evidence_conflicts_and_missing_proof>
Identify contradictions, stale or copied-forward assumptions, missing treatment evidence, wrong body-region documentation, wrong-patient attachments, stale recommendations, red-flag exceptions, and unsupported queue labels.
</evidence_conflicts_and_missing_proof>

<owner_actions>
Identify the owner or team needed to correct, verify, submit, withdraw, or escalate each request.
</owner_actions>

<safe_to_release_or_submit>
Identify requests that looked held or incomplete but are supported for release or submission based on current authoritative evidence.
</safe_to_release_or_submit>

<unresolved_handoff>
Identify unresolved evidence gaps, safety risks, payer criteria issues, and huddle-ready next steps.
</unresolved_handoff>

Focus on whether the evidence supports the requested medical necessity action. Prefer current payer policy and later authoritative source evidence over dashboard labels, copied-forward notes, stale recommendations, or partial worklists. Do not invent missing treatment or procedure evidence. Do not submit solely because the queue says "ready." Also do not keep a request on hold solely because an earlier note says hold if later evidence supports current criteria or a valid red-flag exception. Preserve uncertainty when evidence is insufficient.

## Prompt

It is 10:43 AM, and the medical necessity huddle begins at 11:00 AM.

Review the provided utilization management files and decide:

1. Which requests are evidence-supported and ready for submission?
2. Which requests require hold, correction, withdrawal, more information, or clinical escalation?
3. Which apparent holds can be released because the evidence actually supports proceeding?
4. What evidence supports each determination?

Use the reasoning chain Claim → Evidence → Confidence → Decision.

Also identify owner actions, safe-to-submit cases, unresolved evidence gaps, and huddle-ready next steps.
