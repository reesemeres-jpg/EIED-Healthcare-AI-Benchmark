# Submission006 Strict Grading Guidelines v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Medical Necessity Documentation Review

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

The grading agent should review all 30 source documents together with the model response and any companion output files saved under `/workdir/outputs/`. The evaluation should focus on whether the response correctly determines which requests are evidence-supported and submission-ready, which require hold/correction/withdrawal, which require clinical escalation, and which apparent holds are actually supported for release by current authoritative evidence.

The central test is whether the response respects evidence provenance, current payer criteria, body-region matching, source identity, current examination findings, treatment completion, red-flag exceptions, and later authoritative addenda. Several documents look useful but are dashboards, queue labels, copied-forward fields, old recommendations, preliminary worklists, or incomplete packets rather than proof that medical necessity is supported.

A response should not submit a request simply because the queue says ready, a provider signed the order, a treatment was ordered, or an attachment is present. The inverse is also important: a response should not keep a request on hold when later authoritative evidence resolves the concern or supports a red-flag exception.

Conditional language does not save the response if it still accepts an unsupported submit/hold decision.

## Rating Scale

### Amazing

The response correctly separates Claim, Evidence, Confidence, and Decision for the major cases. It identifies false-ready requests that must be held, withdrawn, or escalated; recognizes false-hold requests that should be released; applies current policy; distinguishes ordered from completed treatment; detects wrong-body-region and wrong-patient evidence; handles stale recommendations and copied-forward exams; applies red-flag exceptions; and assigns realistic owner actions.

An Amazing response must correctly handle:

- Amanda Lewis: release from hold and submit because matched outside lumbar PT and PCP addendum support criteria.
- Brian Carter: hold; PT was ordered but never completed, symptoms are only 4 weeks, and no red flags are present.
- Carla Ruiz: hold/defer; abnormal exam was copied forward and current symptoms/exam improved.
- David Kim: release from hold and submit because authenticated outside injection record supports prior procedure and response.
- Elena Brooks: hold; attached evidence is for shoulder, not knee, and current knee criteria are unsupported.
- Frank Miller: withdraw/cancel or defer; current GI addendum says repeat CT is no longer needed.
- Gina Patel: hold and correct attachment; neurology note belongs to a different patient.
- Hector Alvarez: urgent clinical escalation/release from routine hold because progressive foot drop supports red-flag exception.
- Iris Chen: hold; request overstates PT, prior injection, and exam evidence.
- Jason Moore: release from hold and urgently submit/escalate because later specialist addendum documents possible cervical myelopathy.

### Pretty Good

The response catches the main false-ready traps and correctly releases at least two false-hold cases. It may be somewhat generic in owners or slightly imperfect in urgency wording, but it preserves the central evidence-integrity and medical necessity logic.

### Okay

The response is mixed. It catches some major unsupported requests but misses or softens at least one important identity, body-region, current-exam, treatment-completion, stale-recommendation, or red-flag issue. It may over-hold one supported case while preserving the general logic.

### Pretty Bad

The response attempts the task but fails the core evidence-integrity test. It accepts one or more queue labels as true despite conflicting or missing evidence, or it keeps requests on hold despite authoritative evidence supporting release.

Pretty Bad triggers:
- Keeps Amanda on hold despite matched outside PT and PCP confirmation.
- Submits Brian based on PT order or listed NSAID without completed treatment.
- Submits Carla based on copied-forward abnormal exam.
- Keeps David on hold despite authenticated outside procedure record.
- Submits Elena using shoulder documentation for knee MRI.
- Submits Frank despite current GI addendum cancelling the need for repeat CT.
- Submits Gina based on wrong-patient neurology attachment.
- Keeps Hector in routine PT hold despite progressive foot drop.
- Submits Iris based on unsupported prior injection and overstated exam.
- Keeps Jason on hold despite later myelopathy addendum.
- Relies on preliminary risk flags instead of current source evidence.
- Approves everything or holds everything without evidence.

### Bad

The response substantially fails the task. It summarizes files without making determinations, uses the wrong domain, invents facts, refuses unnecessarily, ignores payer criteria, or produces classifications that are mostly unsupported.

Bad is appropriate if the response:
- Does not identify major evidence failures.
- Does not identify release-from-hold cases.
- Treats the task as generic clinical advice instead of medical necessity documentation review.
- Makes up payer rules not present in the documents.
- Ignores the requested output structure.

## Expected Determinations

### Amanda Lewis — False Hold / Outside PT

Expected Decision: Release from hold and submit.

Evidence:
- Outside PT summary matches patient identity and lumbar current episode.
- Eight visits over 7 weeks.
- Persistent radicular symptoms despite treatment.
- PCP addendum confirms review and supports MRI.

Owner action:
Authorization coordinator should attach outside PT summary and submit.

### Brian Carter — Ordered, Not Completed

Expected Decision: Hold/request more information; not submission-ready.

Evidence:
- Symptoms present 4 weeks.
- No red flags.
- PT was ordered but never scheduled.
- No recent ibuprofen fill.
- Current PCP message recommends continuing conservative care.

Owner action:
Ordering clinician should complete/clarify conservative treatment pathway.

### Carla Ruiz — Copied-Forward Exam

Expected Decision: Hold/defer; not submission-ready.

Evidence:
- Old note had grip weakness and positive Spurling.
- Current exam is normal and symptoms improved.
- Current specialist plan says MRI only if weakness returns or symptoms worsen.
- Request worksheet copied old findings.

Owner action:
Neurology/authorization coordinator should correct current clinical evidence and withdraw or defer request.

### David Kim — False Hold / Outside Procedure

Expected Decision: Release from hold and submit.

Evidence:
- Authenticated outside right L5-S1 injection record.
- 70% relief for about 8 weeks.
- Current radicular pain recurred.
- Current imaging supports same level.

Owner action:
Pain management liaison should link procedure record and submit.

### Elena Brooks — Wrong Body Region

Expected Decision: Hold/correct; not submission-ready.

Evidence:
- Attached note and PT are for right shoulder.
- Request is for left knee.
- Knee pain is 10 days old.
- No mechanical symptoms or supporting current exam.
- Radiograph shows mild osteoarthritis only.

Owner action:
Orthopedic office must provide current left-knee evidence or reconsider request.

### Frank Miller — Stale Recommendation

Expected Decision: Withdraw/cancel or defer; do not submit.

Evidence:
- Old GI note recommended repeat CT.
- Current GI addendum says pain resolved and repeat CT is no longer needed.
- Order came from old recall list.

Owner action:
Ordering office should cancel or withdraw stale request.

### Gina Patel — Wrong-Patient Attachment

Expected Decision: Hold and correct attachment; not submission-ready.

Evidence:
- Attached neurology note has different DOB, address, and phone.
- Correct patient chart shows migraine and no focal deficit or seizure diagnosis.
- No current source supports requested brain MRI.

Owner action:
HIM/ordering provider must remove wrong-patient attachment and reassess indication.

### Hector Alvarez — Red-Flag Exception

Expected Decision: Urgent clinical escalation and release from routine hold.

Evidence:
- New foot drop.
- Dorsiflexion 2/5.
- Progressive weakness.
- Provider documents concern for compressive pathology and same-day spine review.
- Current criteria allow bypass of routine conservative treatment for progressive motor deficit.

Owner action:
UM physician/imaging lead/ordering provider should expedite urgent pathway.

### Iris Chen — Unsupported Treatment History

Expected Decision: Hold/request more information.

Evidence:
- PT only one visit with discharge for nonattendance.
- No prior SI injection note.
- Claims show trigger-point injection, not SI injection.
- Current exam has one positive maneuver, not three.
- Provider note says consider injection after therapy completion.

Owner action:
Pain clinic must correct history and document qualifying pathway.

### Jason Moore — Later Addendum Changes Decision

Expected Decision: Release from hold and urgently submit/escalate.

Evidence:
- Older note supported observation.
- Later specialist addendum documents progressive hand weakness, dropping objects, hyperreflexia, and unsteady gait.
- Specialist states prior observation plan no longer applies.
- Possible cervical myelopathy supports urgent imaging.

Owner action:
Authorization coordinator and imaging utilization physician should expedite current request.

## Evidence Integrity Failure Patterns to Penalize

Penalize responses that:
- Trust queue colors.
- Treat ordered therapy as completed therapy.
- Count treatment for the wrong body region.
- Use copied-forward exam findings as current.
- Treat an attached note as relevant without identity verification.
- Use an old recommendation after a current specialist addendum reverses it.
- Ignore red-flag exceptions.
- Treat procedure claims as completed procedures without source notes.
- Keep stale holds after outside records or later addenda resolve them.
- Approve everything or hold everything without evidence.

## Timing and Execution Constraints

The huddle begins at 11:00 AM. The current time is 10:43 AM. The UM nurse can complete only limited owner outreach before huddle.

A strong response should produce a huddle-ready submit/hold/withdraw/escalate/release list with evidence and owners. It should not claim that every missing record or correction can be completed before the huddle.

## Recommended Rating Posture

Default toward Pretty Bad when the response is polished but accepts unsupported ready-for-submission labels for major false-ready cases.

Default toward Pretty Bad when the response keeps all cases on hold and fails to release Amanda, David, Hector, or Jason despite supporting evidence.

Default toward Okay when the response catches the major cases but is too vague, misses one major trap, or over-holds one supported case.

Default toward Pretty Good only when the response clearly rejects surface labels, applies current criteria, and identifies supported release/submit cases.

Reserve Amazing for responses that are both correct and operationally usable as a huddle-ready medical necessity review using Claim → Evidence → Confidence → Decision.
