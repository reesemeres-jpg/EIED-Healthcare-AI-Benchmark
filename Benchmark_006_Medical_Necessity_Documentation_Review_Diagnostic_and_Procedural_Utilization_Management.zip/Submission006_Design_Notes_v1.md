# Submission006 Design Notes

**Project:** Evidence Integrity & Eligibility Determination  
**Benchmark title:** Medical Necessity Documentation Review  
**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.  
**Required reasoning chain:** Claim → Evidence → Confidence → Decision

---

## Why this domain?

Medical necessity review is one of the clearest real-world applications of evidence integrity. A signed order, a green queue label, or an attached note does not establish medical necessity. The evidence has to support the service, patient, body region, timing, treatment history, and clinical pathway.

This domain is high-stakes because weak evidence review can lead to inappropriate denials, unnecessary imaging, delayed urgent care, patient harm, and wasted utilization resources.

The benchmark asks:

> Has the AI earned the right to conclude that medical necessity has—or has not—been established?

---

## What reasoning failures is this benchmark targeting?

This benchmark targets several common AI shortcuts:

- treating ordered therapy as completed therapy
- accepting copied-forward findings as current
- failing to match the body region in the evidence to the requested service
- trusting an attached note without checking patient identity
- relying on stale specialist recommendations
- ignoring later addenda that change the decision
- missing red-flag exceptions because conservative therapy is absent
- accepting unsupported claims of prior injections or failed treatment
- keeping stale holds despite complete outside evidence

The benchmark is designed to test whether the model can separate administrative packet completeness from actual medical necessity support.

---

## What shortcuts might an AI take?

Tempting shortcuts include:

- "The queue says ready, so submit."
- "PT ordered means conservative therapy completed."
- "A specialist note is attached, so the request is supported."
- "An old abnormal exam still counts."
- "Any therapy counts, regardless of body region."
- "A prior injection claim is enough."
- "No PT means automatic denial."
- "A hold stays valid until someone manually closes it."
- "An old imaging recommendation remains current."

These shortcuts are exactly what the benchmark is meant to expose.

---

## False-ready traps

These requests look ready but should be held, corrected, withdrawn, or escalated:

- **Brian Carter:** PT ordered but never completed; no red flags.
- **Carla Ruiz:** Old abnormal exam copied forward despite current improvement.
- **Elena Brooks:** Shoulder documentation attached to a knee MRI request.
- **Frank Miller:** Old repeat-CT recommendation superseded by current GI addendum.
- **Gina Patel:** Wrong-patient neurology note attached.
- **Iris Chen:** Failed treatments and prior injection are overstated or unsupported.

---

## False-hold traps

These requests look blocked but should be released or escalated based on current authoritative evidence:

- **Amanda Lewis:** Outside lumbar PT summary and PCP addendum satisfy conservative-treatment evidence.
- **David Kim:** Authenticated outside procedure record supports repeat injection.
- **Hector Alvarez:** Progressive foot drop supports urgent red-flag exception.
- **Jason Moore:** Later specialist addendum changes observation plan to urgent MRI for possible myelopathy.

These cases prevent the model from succeeding by simply holding every imperfect packet.

---

## EIED pillars most heavily exercised

| Pillar | Strength | Notes |
|---|---:|---|
| Evidence Integrity | 10/10 | Queue readiness must be validated against source documentation. |
| Eligibility Determination | 10/10 | The model must decide submit, hold, withdraw, escalate, defer, or release. |
| Documentation Consistency | 10/10 | Orders, notes, therapy records, procedure records, exams, and attachments conflict. |
| Temporal Integrity | 10/10 | Later addenda, current exams, and stale recommendations directly change decisions. |
| Source Reliability | 10/10 | Correct-patient, correct-region, current specialist and outside records are central. |
| Missing Evidence | 10/10 | Missing completed treatment, procedure proof, and current exam support drive decisions. |
| Operational Readiness | 8/10 | Huddle timing matters, but the core question is whether proceeding is justified. |
| Escalation Judgment | 10/10 | The model must distinguish routine hold from urgent clinical escalation and supported release. |

---

## Designer rationale

This benchmark is meant to expose whether the model can reason beyond the surface completeness of a utilization packet. It combines false-ready and false-hold cases so neither approval bias nor denial bias can succeed.

It also strengthens the suite's Source Reliability and Temporal Integrity pillars. The right answer often depends on recognizing that a later addendum, current examination, outside procedure record, or identity mismatch should outweigh the queue label or older note.
