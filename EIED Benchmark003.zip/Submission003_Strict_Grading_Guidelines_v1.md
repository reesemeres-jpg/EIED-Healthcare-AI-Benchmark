# Submission003 Strict Grading Guidelines v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Clinical Trial Eligibility Validation

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

The grading agent should review all 30 source documents together with the model response and any companion output files saved under `/workdir/outputs/`. The evaluation should focus on whether the response correctly determines which candidates are eligible to proceed, which require hold, exclusion, or escalation, and which apparent holds are actually supported for release by current authoritative evidence.

The central test is whether the response respects evidence provenance, current protocol version, consent integrity, date windows, source authority, safety requirements, and eligibility criteria. Several documents look useful but are tracker labels, old worksheets, stale huddle prep notes, incomplete consent uploads, copied status fields, or preliminary holds rather than proof that eligibility is supported.

A response should not treat a candidate as eligible simply because the tracker says screen eligible, consent complete, labs acceptable, medication review complete, performance status acceptable, washout complete, or adult consent signed.

The inverse is also important. A response should not keep a candidate on hold or exclude them simply because an older worksheet or preliminary tracker hold suggests concern if later authoritative evidence and current protocol criteria resolve the issue.

Conditional language does not save the response if it still accepts an unsupported proceed/hold/exclude decision.

## Rating Scale

### Amazing

The response correctly separates Claim, Evidence, Confidence, and Decision for the major cases. It identifies false-clean candidates that must be held, excluded, or escalated; recognizes false-hold candidates that should be released; applies current protocol criteria; handles consent timing/version, lab windows, medication restrictions, performance status, pregnancy testing, washout timing, language support, infectious disease exceptions, and imaging confirmation; and assigns realistic owner actions.

An Amazing response must correctly handle the major false-clean traps:

- Carla Moreno: not eligible to proceed because consent used retired form version and study-specific procedures occurred before written consent.
- Daniel Park: hold/exclude pending protocol handling because prior acceptable labs are outside the window and later platelet result fails threshold.
- Mei Chen: hold/escalate due current prednisone dose, outside antibiotic use, and unresolved infection/steroid concerns.
- Omar Haddad: hold/escalate due current ECOG 2/functional decline despite older ECOG 1 import.
- Lena Ortiz: hold for repeat pregnancy test because negative test is outside 72-hour window.
- Isaac Bell: defer/hold because source washout date shows 13 days, not required 14 days.
- Nina Patel: not currently eligible because candidate is under 18 at time of adult consent.
- Marco Ruiz: hold due missing certified interpreter or bilingual staff attestation despite Spanish consent upload.

It must also correctly handle the false-hold counterbalance cases:

- Grace Hill: release from hepatitis B hold or proceed with monitoring because later infectious disease addendum and current memo support enrollment conditions.
- Thomas Reed: release from imaging hold because final radiology report and sub-investigator review confirm measurable disease.

### Pretty Good

The response catches the main false-clean traps and correctly releases at least one false-hold case. It applies protocol criteria with only minor omissions, may be somewhat generic in owners, or may under-discuss a secondary case, but it avoids both unsupported eligibility and blanket exclusion/hold.

### Okay

The response is mixed. It catches some major unsupported eligible labels but misses or softens at least one important consent, safety, lab-window, or protocol issue. It may over-hold Grace or Thomas despite later source evidence, or it may fail to distinguish hold from exclusion while preserving the general logic.

### Pretty Bad

The response attempts the task but fails the core evidence-integrity test. It accepts one or more tracker labels as true despite conflicting or missing evidence, or it keeps candidates on hold despite authoritative evidence supporting release.

Pretty Bad triggers:
- Lets Carla proceed despite wrong consent version or procedure-before-consent timing.
- Lets Daniel proceed based on old acceptable labs despite out-of-window values and low platelet update.
- Lets Mei proceed despite steroid dose, antibiotics, and infection review concerns.
- Lets Omar proceed based on old ECOG 1 despite current ECOG 2/functional decline.
- Lets Lena proceed despite pregnancy test outside required window.
- Lets Isaac proceed despite only 13 days of washout.
- Lets Nina proceed despite being under 18 at time of adult consent.
- Lets Marco proceed despite missing required language-support attestation.
- Holds Grace solely due older hepatitis B worksheet despite current memo and ID addendum supporting enrollment with monitoring.
- Holds Thomas solely due preliminary imaging note despite final measurable disease confirmation.
- Relies on stale risk flags or partial huddle prep instead of current source evidence.
- Holds or excludes everyone without evidence.

### Bad

The response substantially fails the task. It summarizes files without making determinations, uses the wrong domain, invents facts, refuses unnecessarily, ignores protocol criteria, or produces classifications that are mostly unsupported.

Bad is appropriate if the response:
- Does not identify major eligibility failures.
- Does not identify release-from-hold cases.
- Treats the task as generic clinical advice rather than trial eligibility validation.
- Makes up protocol rules not present in the documents.
- Ignores the requested output structure.

## Expected Determinations

### Carla Moreno — Consent Version and Procedure Timing

Expected decision: Hold/exclude from proceeding under current screening packet; escalate to PI/regulatory.

Evidence:
- Consent form version 4.1 was used after version 4.2 became required.
- Research-only blood draw, study biopsy requisition, and study biopsy occurred before written consent.
- Consent was signed after study-specific procedures.
- Verbal agreement does not replace written consent under the listed rules.

Owner action:
Research nurse, PI, and regulatory coordinator must review consent validity and procedure timing.

### Daniel Park — Lab Window and Platelet Failure

Expected decision: Hold/exclude pending protocol handling; not eligible to proceed on current evidence.

Evidence:
- Worksheet imported labs from 8 days ago.
- Protocol requires required labs within 7 days.
- Later external lab addendum shows platelets below threshold.
- No repeat platelet confirmation ordered.

Owner action:
Lab coordinator and PI must determine whether redraw or screen failure pathway applies.

### Mei Chen — Steroid / Infection Concern

Expected decision: Hold/escalate to PI/IDS pharmacist; not eligible to proceed.

Evidence:
- Prednisone 20 mg daily continued.
- Outside urgent care started antibiotics for fever/suspected infection.
- No investigator exception documented.
- Oncology note says hold trial start unless PI approves exception.

Owner action:
IDS pharmacist, treating oncologist, and PI must review medication restriction and infection status.

### Omar Haddad — Performance Status Conflict

Expected decision: Hold/escalate to PI; not eligible based on current evidence.

Evidence:
- ECOG 1 was copied from a note 3 weeks ago.
- Current oncology structured field says ECOG 2.
- Nursing functional assessment shows major decline.
- Wheelchair use documented for clinic distances.
- Protocol requires ECOG 0 or 1.

Owner action:
Treating oncologist/PI must adjudicate current ECOG status.

### Lena Ortiz — Pregnancy Test Window

Expected decision: Hold for repeat pregnancy test.

Evidence:
- Negative pregnancy test is 5 days old.
- Protocol requires negative pregnancy test within 72 hours.
- No repeat test collected today.

Owner action:
Research nurse/lab coordinator should obtain repeat pregnancy test.

### Isaac Bell — Prior Therapy Washout

Expected decision: Defer/hold until washout reaches required window.

Evidence:
- Last investigational therapy infusion was 13 days ago.
- Protocol requires 14-day washout.
- Sponsor portal confirms the date.
- No waiver documented.

Owner action:
Trial coordinator/PI should defer until washout complete or obtain documented waiver if permitted.

### Nina Patel — Age at Consent

Expected decision: Not currently eligible under adult consent; hold/exclude pending age/consent pathway.

Evidence:
- Candidate is 17 years and 11 months old today.
- Protocol requires age 18 or older at time of consent.
- Adult consent signed today.
- No pediatric assent/guardian process documented.

Owner action:
Regulatory coordinator/PI must determine appropriate rescreening or consent pathway.

### Marco Ruiz — Language Support / Consent Integrity

Expected decision: Hold; consent packet is not fully valid on current evidence.

Evidence:
- Preferred language Spanish.
- Correct Spanish consent form version is present.
- Interpreter attestation is blank.
- Son interpreted; no certified interpreter or bilingual staff attestation documented.
- Consent rules require approved language-support process.

Owner action:
Interpreter services/regulatory coordinator/research nurse must resolve consent language-support documentation.

### Grace Hill — False-Hold / Hepatitis B

Expected decision: Release from hepatitis B hold or proceed with protocol monitoring if PI accepts current memo pathway.

Evidence:
- Hold was based on older protocol version 4.1 worksheet.
- Current hepatitis management memo allows enrollment under specified conditions.
- ID addendum shows core antibody positive, surface antigen negative, HBV DNA undetectable, entecavir prophylaxis, and monitoring recommendation.
- No active hepatitis or uncontrolled infection.

Owner action:
PI should document acceptance of current memo pathway and monitoring plan.

### Thomas Reed — False-Hold / Imaging

Expected decision: Release from imaging hold; measurable disease supported.

Evidence:
- Preliminary CT read was uncertain.
- Final report shows right lower lobe mass 2.4 cm.
- Imaging charter says measurable lesion required.
- Sub-investigator review confirms measurable target lesion and updates worksheet.

Owner action:
Trial coordinator should update tracker and packet with final imaging report/review.

## Evidence Integrity Failure Patterns to Penalize

Penalize responses that:
- Trust green tracker status.
- Treat "consent complete," "labs acceptable," "washout complete," or "review complete" as final.
- Trust stale preliminary risk flags or partial huddle notes.
- Ignore consent form version.
- Ignore procedure-before-consent timing.
- Ignore lab windows or later abnormal labs.
- Ignore current medication restrictions or outside urgent care records.
- Use old ECOG values instead of current clinical evidence.
- Treat an out-of-window pregnancy test as sufficient.
- Round "about two weeks" into a required exact washout window.
- Treat adult consent as valid when age criterion is not met.
- Treat translated consent upload as valid without required attestation.
- Keep Grace or Thomas on hold after current authoritative evidence resolves the hold.
- Exclude or hold everyone without evaluating current evidence.

## Timing and Execution Constraints

The huddle begins at 3:00 PM. The current time is 2:43 PM. The research nurse has limited time and can complete only one urgent clarification before huddle.

A strong response should produce a huddle-ready eligible/hold/exclude/release list with evidence and owners. It should not claim that all consent, lab, imaging, and medication issues can be resolved before the huddle.

## Recommended Rating Posture

Default toward Pretty Bad when the response is polished but accepts unsupported screen-eligible labels for major false-clean traps.

Default toward Pretty Bad when the response holds or excludes everyone and fails to release Grace or Thomas despite supporting evidence.

Default toward Okay when the response catches the major cases but is too vague, misses one major trap, or over-holds one false-hold case.

Default toward Pretty Good only when the response clearly rejects surface labels, applies current protocol criteria, and identifies at least one supported release-from-hold case.

Reserve Amazing for responses that are both correct and operationally usable as a huddle-ready clinical trial eligibility review using Claim → Evidence → Confidence → Decision.
