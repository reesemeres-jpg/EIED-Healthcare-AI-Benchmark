# Submission003 Design Notes

**Project:** Evidence Integrity & Eligibility Determination  
**Benchmark title:** Clinical Trial Eligibility Validation  
**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.  
**Required reasoning chain:** Claim → Evidence → Confidence → Decision

---

## Why this domain?

Clinical trial eligibility is a strong fit for the suite because it is criteria-driven, high-stakes, and highly dependent on evidence provenance. A candidate should not proceed because a tracker says screen eligible, and a candidate should not remain on hold because an older worksheet says hold if newer protocol evidence resolves the concern.

This domain adds protocol discipline to the suite: consent version, consent timing, lab windows, washout windows, performance status, medication restrictions, imaging confirmation, language support, and protocol exceptions all matter.

The benchmark asks:

> Has the AI earned the right to say this candidate can proceed?

---

## What reasoning failures is this benchmark targeting?

This benchmark targets the tendency of AI systems to confuse trial tracker status with eligibility evidence.

The main failures include:

- accepting "screen eligible" tracker status without checking protocol criteria
- treating uploaded consent as valid without checking form version, signatures, language support, and timing
- missing study-specific procedures performed before written consent
- using out-of-window labs or ignoring later abnormal results
- relying on old ECOG values instead of current functional evidence
- rounding an exact washout requirement
- overlooking steroid dose, infection status, and outside medication evidence
- treating pregnancy screen completion as valid without checking the 72-hour window
- leaving a case on hold even after later authoritative evidence resolves the hold

---

## What shortcuts might an AI take?

Tempting shortcuts include:

- "The candidate is green in the tracker, so they are eligible."
- "Consent uploaded means consent is valid."
- "Labs acceptable means labs meet the current protocol window."
- "Medication review complete means prohibited meds were checked."
- "ECOG in the worksheet is current."
- "About two weeks is close enough to a 14-day washout."
- "A hold label means the candidate should stay on hold."
- "Hepatitis B history automatically excludes."
- "Preliminary imaging uncertainty overrides a later final report."

The benchmark is designed to punish those shortcuts.

---

## False-clean traps

These candidates look eligible but should be held, excluded, or escalated:

- **Carla Moreno:** Consent form version is retired, and study-specific procedures occurred before written consent.
- **Daniel Park:** Prior acceptable labs are outside the window, and later platelet result fails threshold.
- **Mei Chen:** Current prednisone dose, antibiotics, and infection concern are unresolved.
- **Omar Haddad:** Current ECOG/functional status conflicts with older imported ECOG 1.
- **Lena Ortiz:** Pregnancy test is outside the required 72-hour window.
- **Isaac Bell:** Prior investigational therapy washout is 13 days, not required 14 days.
- **Nina Patel:** Candidate is under 18 at the time of adult consent.
- **Marco Ruiz:** Spanish consent form is present, but required interpreter/bilingual attestation is missing.

---

## False-hold traps

These candidates look blocked but should be released or considered eligible based on later authoritative evidence:

- **Grace Hill:** Older worksheet placed hepatitis B hold, but current memo and ID addendum support enrollment with undetectable HBV DNA, prophylaxis, and monitoring.
- **Thomas Reed:** Preliminary imaging placed measurable-disease hold, but final radiology report and sub-investigator review confirm measurable disease.

These cases prevent the model from succeeding by excluding everyone.

---

## EIED pillars most heavily exercised

| Pillar | Strength | Notes |
|---|---:|---|
| Evidence Integrity | 10/10 | Tracker labels must be validated against source criteria. |
| Eligibility Determination | 10/10 | The model must decide eligible, hold, exclude, escalate, defer, or release from hold. |
| Documentation Consistency | 9/10 | Tracker fields, consent packets, procedure logs, labs, notes, and addenda must be reconciled. |
| Temporal Integrity | 10/10 | Consent timing, lab windows, washout windows, later addenda, and final reports are central. |
| Source Reliability | 10/10 | Current protocol, protocol memo, source labs, final imaging, and specialist addenda are authoritative. |
| Missing Evidence | 9/10 | Interpreter attestation, repeat pregnancy test, waiver/exception documentation, and PI clarification may be absent. |
| Operational Readiness | 8/10 | Huddle timing matters, but the core question is whether proceeding is justified. |
| Escalation Judgment | 10/10 | The model must separate proceed, hold, exclude, PI escalation, and release-from-hold. |

---

## Designer rationale

This benchmark expands the suite into research operations and protocol eligibility, where small evidence differences can determine whether a candidate can ethically and procedurally proceed. It emphasizes temporal integrity more strongly than the first two submissions because consent timing, lab windows, washout timing, and final addenda are central.

It also strengthens source reliability: current protocol and authoritative addenda must beat older tracker fields and stale huddle notes. The goal is not to be conservative by default. The goal is to make the decision the evidence earns.
