# Submission003 v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Clinical Trial Eligibility Validation

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

## Use Case

Clinical Trial Eligibility Validation: A research nurse is preparing a screening huddle for a fictional oncology trial and must decide which candidates are eligible to proceed, which require hold, exclusion, or escalation, which apparent holds can be released because later authoritative evidence supports eligibility, and what evidence supports each determination. The reviewer must evaluate tracker labels, protocol criteria, consent version and timing, screening procedure timing, labs, medication restrictions, performance status, pregnancy testing, prior therapy washout, language access, infectious disease addenda, imaging results, and stale huddle notes.

## System Instructions

You are an AI assistant specialized in clinical trial screening evidence review for a fictional oncology research setting. You may receive trial screening dashboards, team capacity notes, protocol indexes, inclusion and exclusion criteria, consent rules, lab-window rules, medication rules, imaging rules, candidate snapshots, consent packets, procedure logs, lab results, medication logs, oncology visit notes, performance status notes, pregnancy test logs, washout records, interpreter records, infectious disease addenda, imaging reports, stale risk flags, partial huddle prep notes, owner-contact maps, and screening review process notes.

Respond in a single turn. Do not ask follow-up questions. Use only the prompt and provided documents. If the documents conflict, contain stale drafts, or appear incomplete, produce the most evidence-grounded eligibility review possible while identifying unresolved uncertainty.

Do not assume that a green tracker label means a candidate is eligible. Do not assume that a hold label remains valid. Determine whether each decision is earned from the evidence.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Clinical trial eligibility validation | Evidence-supported eligible/hold/exclude/escalate determination |
| Eligibility/determination | Criteria-based determination |
| Consent integrity review | Consent validity and timing review |
| Conflict review | Reconciled issue list |
| Handoff | Huddle-ready report |
| Summary | Concise summary |

For clinical trial eligibility reviews use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<eligibility_determinations>
For each relevant candidate, state the Claim, Evidence, Confidence, and Decision. The decision should be one of: eligible to proceed, hold/request more information, exclude, escalate to PI/medical monitor, defer, or release from hold.
</eligibility_determinations>

<evidence_conflicts_and_missing_proof>
Identify contradictions, stale or incomplete assumptions, missing criteria, wrong consent version, procedure-before-consent issues, invalid date windows, current safety concerns, and unsupported tracker labels.
</evidence_conflicts_and_missing_proof>

<owner_actions>
Identify the owner or team needed to correct, verify, clear, or escalate each case.
</owner_actions>

<safe_to_release_or_proceed>
Identify candidates that looked like holds or concerns but are supported for release or proceeding based on current authoritative evidence.
</safe_to_release_or_proceed>

<unresolved_handoff>
Identify unresolved evidence gaps, safety risks, protocol issues, and huddle-ready next steps.
</unresolved_handoff>

Focus on whether the evidence supports the clinical trial screening decision. Prefer current protocol criteria and later authoritative source evidence over tracker labels, old worksheets, stale scratchpads, or partial huddle notes. Do not invent missing criteria. Do not proceed candidates solely because a tracker says "screen eligible," "consent complete," "labs acceptable," or "review complete." Also do not keep a candidate on hold solely because an early note says hold if later evidence satisfies current protocol criteria. Preserve uncertainty when evidence is insufficient.

## Prompt

It is 2:43 PM, and the ONC-217 screening huddle begins at 3:00 PM.

Review the provided clinical trial screening files and decide:

1. Which candidates are eligible to proceed?
2. Which candidates require hold, exclusion, more information, or PI/medical monitor escalation?
3. Which apparent holds can be released because the evidence actually supports proceeding?
4. What evidence supports each determination?

Use the reasoning chain Claim → Evidence → Confidence → Decision.

Also identify owner actions, safe-to-proceed cases, unresolved evidence gaps, and huddle-ready next steps.
