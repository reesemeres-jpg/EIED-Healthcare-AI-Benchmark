# Submission005 Design Notes

**Project:** Evidence Integrity & Eligibility Determination  
**Benchmark title:** Medical Necessity Documentation Review  
**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.  
**Required reasoning chain:** Claim → Evidence → Confidence → Decision

---

## Why this domain?

Medical necessity documentation review is a natural fit for the suite because it asks whether a requested service is actually supported by the chart. Many requests look complete because they contain a signed certification, supplier packet, checklist, or template phrase. But medical necessity requires source evidence tied to the specific service.

This domain tests the difference between:

- wanted versus medically necessary
- ordered versus supported
- signed versus sufficient
- supplier-ready versus criteria-supported
- held due missing evidence versus resolved by later documentation

The central question is:

> Has the AI earned the right to say this service is medically necessary?

---

## What reasoning failures is this benchmark targeting?

This benchmark targets AI shortcuts around care coordination and DME documentation.

The main failures include:

- accepting signed home health certifications without checking skilled need or homebound support
- treating supplier packets as authoritative
- accepting old wound measurements as current
- missing later treatment-plan changes
- using acute-illness oxygen values after stable testing no longer qualifies
- treating comfort or preference as hospital bed necessity
- ignoring in-home usability for mobility equipment
- continuing home infusion after ID changes the plan to oral therapy
- extending therapy based on template language despite no functional progress
- keeping holds despite later addenda resolving them

---

## What shortcuts might an AI take?

Tempting shortcuts include:

- "The certification is signed, so approve."
- "The supplier packet says medical necessity, so it is supported."
- "An old qualifying test still counts."
- "A patient wants help at home, so home health is medically necessary."
- "A wheelchair recommendation means this exact wheelchair and cushion are supported."
- "Home infusion is skilled because infusion sounds skilled."
- "A hold should stay until someone manually removes it."
- "Missing internal sleep study means CPAP cannot be supported."

The benchmark is built to expose those shortcuts.

---

## False-supported traps

These requests look supported but should be held, corrected, deferred, or escalated:

- **Margaret Lane:** Signed home health certification but no clear skilled nursing need or homebound status.
- **Alan Pierce:** NPWT packet says supported, but current wound note says do not start until debridement and vascular review.
- **Bethany Cole:** Hospital bed packet says criteria met, but source evidence supports comfort/preference only.
- **Rosa Medina:** Oxygen packet uses old acute pneumonia saturation, while current stable testing does not qualify.
- **Curtis Grant:** Wheelchair/cushion packet is supplier-ready, but in-home usability and cushion support are incomplete.
- **Elaine Park:** Home infusion packet still lists IV antibiotics after ID addendum cancels PICC and moves to oral therapy.
- **Jacob Flynn:** PT extension uses template medical necessity language despite unchanged function and poor adherence.

---

## False-hold traps

These requests look blocked but should be released based on later authoritative evidence:

- **Nadia Ortiz:** Home health PT hold says homebound missing, but later PT/physician addendum supports homebound skilled therapy need.
- **Samuel Brooks:** NPWT hold says wound documentation insufficient, but later wound care addendum supplies required measurements, debridement, treatment plan, and stalled healing.
- **Irene Chen:** CPAP hold says sleep study missing, but matched outside sleep study and equipment failure records support replacement.

These cases prevent the model from succeeding by holding every request.

---

## EIED pillars most heavily exercised

| Pillar | Strength | Notes |
|---|---:|---|
| Evidence Integrity | 10/10 | Packets, checklists, and certifications must be validated against source documentation. |
| Eligibility Determination | 10/10 | The model must decide support, hold, correct, defer, escalate, or release. |
| Documentation Consistency | 9/10 | Packets conflict with notes, testing, addenda, and therapy/wound records. |
| Temporal Integrity | 9/10 | Later wound, ID, PT, respiratory, and sleep records alter earlier packet status. |
| Source Reliability | 10/10 | Current clinical notes and addenda outweigh supplier packets and stale scratchpads. |
| Missing Evidence | 10/10 | Skilled need, homebound support, current testing, home usability, and progress data may be missing. |
| Operational Readiness | 8/10 | The huddle requires practical service decisions, but evidence sufficiency is primary. |
| Escalation Judgment | 10/10 | The model must distinguish approval, hold, correction, deferral, and release from hold. |

---

## Designer rationale

This benchmark strengthens the suite's medical necessity pillar and broadens the benchmark set beyond PA, registry, and trial eligibility. It is valuable because medical necessity errors often come from administrative shortcuts: signed forms, supplier-ready packets, and copied phrases that sound official but do not actually meet criteria.

It also builds the suite's counterbalance pattern. Some requests truly lack evidence, but others are fully supported by later documentation despite stale holds. The model has to decide what the evidence earns, not what the queue label implies.
