# Submission005 Strict Grading Guidelines v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Medical Necessity Documentation Review

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

The grading agent should review all 30 source documents together with the model response and any companion output files saved under `/workdir/outputs/`. The evaluation should focus on whether the response correctly determines which service requests are supported by current medical necessity documentation, which require hold/correction/escalation, which should be deferred, and which apparent holds are actually supported for release by later authoritative evidence.

The central test is whether the response respects evidence provenance, current service criteria, source authority, service-specific documentation requirements, homebound/skilled need distinctions, test validity, current treatment plans, and later addenda. Several documents look useful but are queue labels, supplier packets, signed checkboxes, copied templates, stale scratchpads, or partial huddle prep notes rather than proof that medical necessity is supported.

A response should not approve or certify a request simply because the dashboard says documentation complete, criteria met, medical necessity supported, DME ready, or skilled service supported.

The inverse is also important. A response should not keep a request on hold simply because an early note says homebound missing, wound documentation insufficient, or sleep study missing if later authoritative evidence satisfies the criteria.

Conditional language does not save the response if it still accepts an unsupported approve/hold decision.

## Rating Scale

### Amazing

The response correctly separates Claim, Evidence, Confidence, and Decision for the major cases. It identifies false-supported requests that should be held, corrected, deferred, or escalated; recognizes false-hold requests that should be released; applies current service criteria; distinguishes skilled need from custodial/routine support; distinguishes current testing from stale testing; and assigns realistic owner actions.

An Amazing response must correctly handle the major false-supported traps:

- Margaret Lane: hold; source evidence does not support ongoing skilled nursing need or homebound status.
- Alan Pierce: hold; NPWT packet relies on stale measurements and current wound note says not to start until debridement/vascular review.
- Bethany Cole: hold; hospital bed documentation supports comfort/preference, not qualifying positioning need.
- Rosa Medina: hold/correct; older acute pneumonia oxygen value does not support current stable home oxygen when current testing does not qualify.
- Curtis Grant: hold/correct; wheelchair/cushion request lacks in-home usability and current cushion need.
- Elaine Park: hold/correct; current ID update cancels IV plan and supports oral therapy pathway instead.
- Jacob Flynn: hold; PT extension lacks progress, adherence, and updated functional support.

It must also correctly handle the false-hold counterbalance cases:

- Nadia Ortiz: release/support home health PT because later PT/physician addendum supports homebound status and skilled therapy need.
- Samuel Brooks: release/support NPWT because later wound addendum supplies current measurements, debridement, treatment plan, and stalled healing.
- Irene Chen: release/support CPAP replacement because matched outside sleep study and equipment failure documentation resolve the missing internal study.

### Pretty Good

The response catches the main false-supported traps and correctly releases at least two false-hold cases. It applies service criteria with only minor omissions, may be somewhat generic in owners, or may under-discuss one secondary case, but it avoids both unsupported approval and blanket hold/escalation.

### Okay

The response is mixed. It catches some major unsupported approvals but misses or softens at least one important service-specific criteria failure. It may over-hold one false-hold case despite later evidence, or it may fail to clearly separate hold, correction, deferral, and supported release while preserving the general logic.

### Pretty Bad

The response attempts the task but fails the core evidence-integrity test. It accepts one or more queue labels or packets as true despite conflicting or missing evidence, or it keeps requests on hold despite authoritative evidence supporting release.

Pretty Bad triggers:
- Certifies Margaret based on signed home health certification despite lack of skilled need/homebound support.
- Approves Alan NPWT despite stale measurements and current wound note saying not to start.
- Approves Bethany hospital bed based on comfort/GERD language alone.
- Approves Rosa oxygen based on old acute-illness saturation despite current non-qualifying testing.
- Approves Curtis wheelchair/cushion despite home usability and cushion criteria gaps.
- Approves Elaine home infusion despite ID addendum cancelling IV plan.
- Approves Jacob PT extension despite lack of measurable progress and inconsistent attendance.
- Keeps Nadia on hold despite later PT/physician addendum supporting homebound skilled PT.
- Keeps Samuel on hold despite later wound care addendum satisfying missing documentation.
- Keeps Irene on hold despite matched outside sleep study and equipment failure documentation.
- Relies on stale preliminary flags or partial huddle prep instead of source evidence.
- Holds or approves everything without evidence.

### Bad

The response substantially fails the task. It summarizes files without making determinations, uses the wrong domain, invents facts, refuses unnecessarily, ignores service criteria, or produces classifications that are mostly unsupported.

Bad is appropriate if the response:
- Does not identify major unsupported service requests.
- Does not identify release-from-hold cases.
- Treats the task as generic discharge planning rather than medical necessity review.
- Makes up criteria not present in the documents.
- Ignores the requested output structure.

## Expected Determinations

### Margaret Lane — Home Health Skilled Nursing

Expected decision: Hold/request correction. Not supported for certification on current evidence.

Evidence:
- Incision clean/dry, staples removed.
- Dressing is dry gauze for comfort for 3 more days.
- Patient demonstrated dressing change independently.
- Ambulates independently and drove herself to follow-up.
- Plans return to office work.
- These conflict with skilled nursing and homebound support.

Owner action:
Ordering provider/home health liaison should revise or cancel request, or document qualifying skilled/homebound need if present.

### Alan Pierce — Negative Pressure Wound Therapy

Expected decision: Hold/defer NPWT.

Evidence:
- Packet uses 22-day-old measurements.
- Current wound has adherent slough/eschar.
- Debridement deferred due vascular evaluation pending.
- Wound clinician says do not start NPWT until debridement and vascular review completed.
- No updated NPWT order posted.

Owner action:
Wound care nurse/provider must update wound plan after debridement/vascular review.

### Bethany Cole — Hospital Bed

Expected decision: Hold/request more information. Not supported on current evidence.

Evidence:
- Documentation is comfort/GERD/back pain based.
- No aspiration events, orthopnea, qualifying positioning restriction, or failed pillows/wedges documented.
- Wedge pillow was discussed but not tried.
- No note states regular bed is inadequate.

Owner action:
Ordering provider/DME coordinator must obtain qualifying positioning documentation or revise request.

### Rosa Medina — Home Oxygen

Expected decision: Hold/correct. Not supported by current testing.

Evidence:
- Qualifying 88% value is from acute pneumonia admission 4 weeks ago.
- Current stable room-air resting SpO2 is 94%.
- Ambulatory room-air SpO2 is 92%.
- Provider note says she does not appear to qualify on today's testing.
- No overnight oximetry attached.

Owner action:
Respiratory therapist/provider should update packet or obtain valid current qualifying test if indicated.

### Curtis Grant — Wheelchair and Pressure Cushion

Expected decision: Hold/correct.

Evidence:
- Patient ambulates 150 feet with rollator and standby assist.
- Limitation appears community-distance focused rather than in-home access.
- Bathroom doorway is 26 inches; requested wheelchair is 28 inches.
- No active pressure injury; current pressure-risk support is absent.
- PT says in-home usability uncertain.

Owner action:
PT/DME coordinator must clarify in-home mobility limitation, home usability, and cushion criteria.

### Elaine Park — Home Infusion Antibiotics

Expected decision: Hold/correct; current IV home infusion request not supported.

Evidence:
- Current culture supports oral therapy.
- ID addendum says cancel PICC and transition to oral linezolid if CBC monitoring arranged.
- Home infusion packet still lists IV ceftriaxone.
- PICC scheduling module not updated.
- No revised infusion medical necessity note posted.

Owner action:
Infectious disease/ordering provider/home infusion team must cancel or revise packet and arrange monitoring if oral plan proceeds.

### Jacob Flynn — Outpatient PT Extension

Expected decision: Hold/request more information. Not supported for additional skilled visits on current evidence.

Evidence:
- 10 visits completed.
- Functional score unchanged.
- Pain unchanged.
- 5 missed visits.
- Limited progress due inconsistent attendance and home exercise nonadherence.
- No updated objective functional goals or physician reassessment.

Owner action:
Physical therapist/provider must document measurable progress, revised plan, or alternative disposition.

### Nadia Ortiz — False-Hold / Home Health PT

Expected decision: Release from hold/support home health PT.

Evidence:
- Early hold said homebound missing.
- Later PT and physician addendum document post-op hip fracture repair.
- Requires walker and caregiver assist to leave home.
- Unable to manage stairs safely without two-person assist.
- Leaving home requires taxing effort/medical transport.
- Skilled PT needs documented.

Owner action:
Home health liaison/care coordination nurse should attach addendum and proceed with certification.

### Samuel Brooks — False-Hold / NPWT

Expected decision: Release from hold/support NPWT.

Evidence:
- Early hold lacked measurements/debridement documentation.
- Later wound addendum documents stage 3 sacral pressure injury, current measurements, clean granulation after debridement, stalled healing after 4 weeks, NPWT settings/frequency, and caregiver limitation.
- No unresolved devitalized tissue contraindication remains.

Owner action:
Wound care nurse/DME coordinator should attach addendum and proceed.

### Irene Chen — False-Hold / CPAP Replacement

Expected decision: Release from hold/support CPAP replacement.

Evidence:
- Internal sleep study missing.
- Matched outside sleep study supports OSA diagnosis and titration.
- DME repair record shows machine motor failure and replacement threshold met.
- Compliance download shows ongoing use and benefit.
- Current sleep medicine order confirms replacement settings.

Owner action:
Respiratory therapist/DME coordinator should attach outside study and equipment records.

## Evidence Integrity Failure Patterns to Penalize

Penalize responses that:
- Trust queue colors.
- Treat signed certifications, supplier-ready packets, or checklist fields as proof.
- Treat requested, ordered, planned, delivered, or preferred as medically necessary.
- Treat routine/custodial care as skilled need.
- Treat non-current measurements or acute-illness testing as current support.
- Ignore later treatment-plan changes.
- Ignore homebound evidence or lack of it.
- Ignore home usability for mobility equipment.
- Keep stale holds despite later addenda resolving them.
- Approve everything or hold everything without evidence.

## Timing and Execution Constraints

The huddle begins at 2:00 PM. The current time is 1:43 PM. The care coordination nurse has limited time and can complete only limited owner outreach before huddle.

A strong response should produce a huddle-ready supported/hold/correct/release list with evidence and owners. It should not claim that all packets, orders, testing, and addenda can be corrected before the huddle.

## Recommended Rating Posture

Default toward Pretty Bad when the response is polished but accepts unsupported medical necessity labels for major false-supported traps.

Default toward Pretty Bad when the response holds everything and fails to release Nadia, Samuel, or Irene despite supporting evidence.

Default toward Okay when the response catches the major cases but is too vague, misses one major trap, or over-holds one false-hold case.

Default toward Pretty Good only when the response clearly rejects surface labels, applies service criteria, and identifies supported release-from-hold cases.

Reserve Amazing for responses that are both correct and operationally usable as a huddle-ready medical necessity review using Claim → Evidence → Confidence → Decision.
