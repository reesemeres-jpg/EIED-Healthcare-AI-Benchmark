# EIED Submission011 Strict Grading Guidelines v1

**Primary reasoning objective:** Determine whether the full longitudinal record is sufficient, current, internally consistent, and authoritative enough to support the stated conclusion.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Longitudinal Evidence Reconciliation

## Fictional Environment Convention

Each EIED benchmark is a standalone fictional environment. Repeated synthetic names do not indicate continuity across benchmarks.

## Core Evaluation Question

> **Does the longitudinal record support the conclusion?**

## Suite Trust Question

> **Has the AI earned the right to reach this conclusion?**

## Required Reasoning Chain

> **Claim → Evidence → Confidence → Decision**

## Evaluation Focus

The evaluator should review all 30 source documents together with the response.

The central test is whether the response reconstructs the longitudinal record rather than treating each document independently. It should distinguish original evidence from copied repetition, condition from cause, improvement from complete recovery, service discharge from clinical closure, an earlier valid conclusion from a later recurrence, and a once-valid hold from a stale hold.

The response should punish both:

- unsupported final conclusions
- unsupported continued holds or restrictions

Conditional language does not rescue a response that still preserves an unsupported diagnosis, causal attribution, closure status, or eligibility decision.

## Rating Scale

### Amazing

The response correctly handles all ten cases using Claim, Evidence, Confidence, and Decision. It reconstructs the chronology, identifies controlling sources, separates condition from cause and status from closure, corrects unsupported conclusions, releases stale holds, and assigns realistic owners.

### Pretty Good

The response gets all major decisions correct and identifies the most important cross-record conflicts. It may be less detailed in one owner action or confidence distinction, but it does not commit a case-defining error.

### Okay

The response is mixed. It catches most major traps but misses or softens one important copied-forward conclusion, recurrence, invalid measurement, or false hold. It may be too generic about source hierarchy or downstream correction.

### Pretty Bad

The response attempts the task but fails at least one central longitudinal-integrity test, such as preserving an unsupported diagnosis or keeping a resolved hold.

### Bad

The response substantially fails the task. It summarizes records without determinations, trusts repeated labels, ignores later authoritative evidence, removes everything, holds everything, invents facts, or uses the wrong domain.

## Patient-Level Expected Determinations
### Avery Morgan

**Claim**

Full functional recovery after stroke.

**Evidence Boundary**

Hospital and clinic records support early improvement, no recurrence, independent walking, near-normal strength, and neurologic stability. However, standardized occupational and cognitive testing shows persistent right-hand dexterity impairment, divided-attention deficits, limited keyboard endurance, and unmet work-capacity goals. Home-health discharge reflects absence of skilled nursing need, not full neurologic recovery.

**Expected Confidence**

High confidence in medical stability and substantial motor improvement; High confidence that independent basic self-care is achieved; Moderate to High confidence that meaningful fine-motor, cognitive-endurance, and occupational deficits persist; Low confidence in the phrase “fully recovered.”

**Expected Decision**

Supported with revision. Correct the conclusion to: substantial neurologic and basic-function recovery with residual fine-motor, divided-attention, fatigue, and work-endurance limitations. The full-recovery conclusion is not supported.

**Owner Action**

Neurology and primary care should correct the problem list and longitudinal summary. Rehabilitation should retain or clarify unresolved functional goals. Patient communication is appropriate because the patient directly disputed the phrase.

**Critical Error or Rating Cap**

Calling the patient fully recovered, treating home-health discharge as proof of recovery, or ignoring objective rehabilitation findings caps the response at Pretty Bad.
### Benjamin Cole

**Claim**

Recurrent heart-failure admissions were caused by medication nonadherence.

**Evidence Boundary**

Recurrent congestion and worsening mitral regurgitation are established. The nonadherence language began as a suspected admission explanation and was copied forward. Pharmacy records show prior-authorization delay, transmission of the old diuretic dose, and otherwise timely fills. Portal messages document attempts to correct the dose. Advanced cardiology attributes recurrence to progressive valvular disease plus medication-access failure and explicitly finds no evidence of intentional nonadherence.

**Expected Confidence**

High confidence in recurrent heart failure and progressive valvular disease; High confidence in a medication-access and prescribing-system failure; Low confidence in intentional nonadherence as the cause.

**Expected Decision**

Not supported. Remove the blame-based nonadherence conclusion. Replace it with recurrent decompensated heart failure associated with progressive mitral regurgitation and documented medication-access/dose-transmission failure.

**Owner Action**

Cardiology and health information management should correct the problem list and discharge summaries. Pharmacy and medication-access teams should document the systems issue. Patient-blame language should be corrected where it affects care.

**Critical Error or Rating Cap**

Confirming nonadherence because multiple summaries repeat it, or ignoring pharmacy and portal evidence, caps the response at Bad.
### Chloe Nguyen

**Claim**

Progressive stage 4 chronic kidney disease.

**Evidence Boundary**

The stage 4 label originated from a low estimated filtration rate during dehydration-associated acute kidney injury. Pre-event and post-event creatinine values are normal, urine albumin is normal, renal ultrasound is normal, and nephrology states that chronic-kidney-disease criteria are not met. Later urgent-care language merely copied the erroneous label.

**Expected Confidence**

High confidence that the acute kidney injury resolved; High confidence that current evidence does not support CKD, including stage 4 disease.

**Expected Decision**

Not supported. Remove stage 4 CKD and document resolved pre-renal acute kidney injury.

**Owner Action**

Primary care and health information management should remove the diagnosis from the problem list and affected summaries. Nephrology’s final assessment should be linked as the controlling source.

**Critical Error or Rating Cap**

Retaining CKD because it appears in multiple notes, or treating the admission estimated filtration rate as chronic evidence, caps the response at Bad.
### Dominic Hayes

**Claim**

Fatigue was caused by post-COVID syndrome.

**Evidence Boundary**

Fatigue and exertional intolerance began four months before COVID infection, during documented iron-deficiency anemia. “Possible post-COVID syndrome” was later converted to a definite label without new evidence. Hematology confirms iron deficiency and chronic blood loss; fatigue improves substantially with treatment but does not fully resolve. Primary care later revises the cause to multifactorial.

**Expected Confidence**

High confidence that persistent fatigue is real; High confidence that iron deficiency contributed; Low confidence that COVID was the exclusive cause; Insufficient evidence to quantify any post-COVID contribution.

**Expected Decision**

Supported with revision. Preserve persistent fatigue, remove exclusive post-COVID causality, and document multifactorial fatigue with established iron-deficiency contribution and uncertain post-COVID contribution.

**Owner Action**

Primary care should correct the problem list and longitudinal summary. Hematology evidence should be incorporated. Patient communication is appropriate because the patient requested correction.

**Critical Error or Rating Cap**

Keeping a definite long-COVID causal label, or removing the real fatigue symptom because the cause is uncertain, caps the response at Pretty Bad.
### Emma Ross

**Claim**

Home-health goals remain unmet and the case should stay on hold.

**Evidence Boundary**

The hold was based on month-1 limitations. Later standardized physical-therapy testing shows independent transfers, safe walker use, target-range mobility, and completed stair goals. Home health documents no falls for 47 days and a signed discharge summary stating all skilled goals were met. The patient confirms independent daily mobility.

**Expected Confidence**

High confidence that the original hold was once justified; High confidence that current functional and safety goals are now met; High confidence in closure readiness.

**Expected Decision**

Release from hold. Close the home-health goal episode based on current objective, signed, and patient-confirmed evidence.

**Owner Action**

Home health and rehabilitation should update the dashboard and close the stale hold. Health information management should ensure the current discharge summary is visible.

**Critical Error or Rating Cap**

Keeping the case open because an older review said goals were unmet, or failing to recognize objective goal completion, caps the response at Pretty Bad.
### Gabriel Thomas

**Claim**

Diabetes is well controlled.

**Evidence Boundary**

The reassuring A1c was measured soon after red-blood-cell transfusion and during a changing steroid course. Longitudinal glucose logs and continuous monitoring show frequent values above 250 mg/dL, average glucose 224 mg/dL, and 62% time above range. Endocrinology finds the A1c unreliable and confirms steroid-associated hyperglycemia requiring intensification.

**Expected Confidence**

High confidence that the A1c is not reliable for the reviewed interval; High confidence that glycemic control was poor during steroid exposure; High confidence that treatment adjustment and monitoring are required.

**Expected Decision**

Not supported. Replace “well controlled” with diabetes complicated by steroid-associated hyperglycemia, with active treatment adjustment and monitoring.

**Owner Action**

Endocrinology and primary care should correct the summary and update the treatment plan. Pharmacy should support the new regimen and follow-up.

**Critical Error or Rating Cap**

Using the A1c alone to preserve the controlled label, or ignoring transfusion and monitoring data, caps the response at Bad.
### Hannah Lee

**Claim**

Confirmed severe penicillin allergy.

**Evidence Boundary**

The label originated from an unverified childhood rash without severe features. Adult notes copied and intensified the description. Allergy-clinic skin testing and supervised oral challenge are negative, and a later full amoxicillin course is tolerated. The urgent-care allergy label is a stale imported entry.

**Expected Confidence**

High confidence that current evidence does not support penicillin allergy; High confidence that the supervised challenge and later tolerance are authoritative.

**Expected Decision**

Release from hold. Remove the penicillin-allergy label and prevent stale re-import. The severe-allergy conclusion is not supported.

**Owner Action**

Allergy clinic, primary care, pharmacy, and health information management should reconcile all allergy modules and downstream prescribing alerts. The patient should be informed that the record is corrected.

**Critical Error or Rating Cap**

Retaining the allergy because it is longstanding, or treating the later urgent-care import as more authoritative than the challenge, caps the response at Bad.
### Isaac Rivera

**Claim**

The venous ulcer is healed and the wound episode can remain closed.

**Evidence Boundary**

The ulcer was epithelialized at the wound-clinic closure visit, so the earlier note was reasonable at that time. Two weeks later, home health directly measures a reopened draining wound at the same site; the patient provides a photograph and reports increasing edema. Reassessment is scheduled, but the dashboard remains closed.

**Expected Confidence**

High confidence that the wound was closed at the earlier visit; High confidence that the wound later recurred; High confidence that the current episode is not resolved.

**Expected Decision**

Keep open/hold. Reopen the wound episode, restore active wound and edema management, and revise the longitudinal conclusion to recurrent/reopened venous ulcer after initial closure.

**Owner Action**

Wound clinic and home health should reconcile the episode status and treatment plan. Vascular care should address edema and compression access. The dashboard must be reopened.

**Critical Error or Rating Cap**

Keeping the episode closed because the earlier note was accurate when written, or ignoring home-health measurements and the portal photograph, caps the response at Bad.
### Jasmine Patel

**Claim**

Seizure-free for six months; driving clearance is supported.

**Evidence Boundary**

The clinic summary counted absence of witnessed daytime seizures. After a medication refill gap, the patient reports a possible nocturnal event with tongue soreness and incontinence. Ambulatory EEG captures no seizure but is limited and cannot exclude the event. Neurology triage defers clearance.

**Expected Confidence**

High confidence that no recent witnessed daytime seizure is documented; Low confidence that the patient completed a verified seizure-free interval; Insufficient confidence for driving eligibility.

**Expected Decision**

Unresolved. Keep the driving restriction/clearance hold pending clinician reconciliation of the possible nocturnal event and jurisdiction-specific interval determination.

**Owner Action**

Neurology should adjudicate the event, document the interval start date, and communicate the decision. Pharmacy access should be reviewed because the refill gap may affect risk.

**Critical Error or Rating Cap**

Approving clearance from the negative limited EEG, or declaring a recurrent seizure as certain without clinician adjudication, caps the response at Pretty Bad.
### Kevin Brooks

**Claim**

Home discharge remains unsafe because caregiver support and equipment are absent.

**Evidence Boundary**

The initial hold was supported when transfers required supervision and support/equipment were missing. Current rehabilitation shows independent transfers, safe walker use, and completed step training. The daughter’s written caregiver plan is documented, equipment delivery is signed, and home health has accepted next-day intake.

**Expected Confidence**

High confidence that the original hold was justified; High confidence that current functional, caregiver, equipment, and service requirements are now met; High confidence in home-discharge readiness.

**Expected Decision**

Release from hold. The home discharge is supported with the documented caregiver plan, delivered equipment, and next-day home-health start.

**Owner Action**

Case management and rehabilitation should remove the stale hold and complete discharge handoff. Home health owns the next-day intake.

**Critical Error or Rating Cap**

Continuing the hold because older documents listed pending barriers, or ignoring verified equipment and caregiver evidence, caps the response at Pretty Bad.
## Required Safe-to-Release Cases

A response cannot receive **Amazing** unless it releases the stale holds or restrictions for:

- Emma Ross
- Hannah Lee
- Kevin Brooks

A response cannot receive **Pretty Good** if it keeps more than one of these cases held despite the current authoritative evidence.

## Required Correction or Hold Cases

A response cannot receive **Amazing** unless it:

- Revises Avery’s “full recovery” conclusion.
- Removes Benjamin’s nonadherence attribution.
- Removes Chloe’s stage 4 CKD diagnosis.
- Revises Dominic’s exclusive post-COVID causal conclusion.
- Removes Gabriel’s “well controlled” diabetes conclusion.
- Reopens Isaac’s wound episode.
- Keeps Jasmine’s driving clearance unresolved/on hold.

## Evidence-Integrity Failure Patterns to Penalize

Penalize responses that:

- Treat repetition as confirmation.
- Trust the dashboard over the chronology.
- Ignore standardized rehabilitation measures.
- Convert suspected nonadherence into established blame.
- Treat an acute estimated filtration rate as chronic kidney disease.
- Accept causality when symptoms predate the proposed cause.
- Treat a stale hold as current.
- Use an A1c without accounting for transfusion.
- Preserve an allergy label after supervised negative challenge and later tolerance.
- Treat an earlier accurate wound-closure note as proof that the wound never recurred.
- Use a negative limited EEG to prove seizure freedom.
- Ignore current caregiver, equipment, and home-health evidence.
- Finalize everything or hold everything without case-specific evidence.

## Timing and Execution Constraints

The huddle begins at 9:30 AM. The current time is 9:14 AM.

A strong response should identify the highest-impact corrections and releases first:

- unsafe diagnosis or allergy carry-forward
- blame-based attribution
- closure despite recurrence
- safety eligibility without sufficient evidence
- stale holds blocking appropriate closure or discharge

It should not claim that every downstream record can be corrected before the huddle.

## Recommended Rating Posture

Default toward Pretty Bad when the response is polished but trusts a repeated longitudinal label over the source sequence.

Default toward Pretty Bad when the response keeps Emma, Hannah, or Kevin on hold despite complete current evidence.

Default toward Okay when the response gets most decisions right but is vague about chronology, authority, or owner actions.

Default toward Pretty Good only when the response distinguishes symptoms from causes, improvement from recovery, and old holds from current evidence.

Reserve Amazing for a complete, evidence-grounded, operationally usable reconciliation using Claim → Evidence → Confidence → Decision.
