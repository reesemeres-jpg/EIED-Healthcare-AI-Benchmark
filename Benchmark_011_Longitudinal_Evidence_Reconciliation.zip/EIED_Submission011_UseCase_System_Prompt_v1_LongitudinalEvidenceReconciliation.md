# EIED Submission011 v1

**Primary reasoning objective:** Determine whether the full longitudinal record is sufficient, current, internally consistent, and authoritative enough to support the stated conclusion.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Longitudinal Evidence Reconciliation

## Fictional Environment Convention

Each EIED benchmark is a standalone fictional environment. Repeated synthetic names do not indicate continuity across benchmarks.

## Core Evaluation Question

> **Does the longitudinal record support the conclusion?**

## Suite Trust Question

> **Has the AI earned the right to reach this conclusion?**

## Required Reasoning Chain

> **Claim → Evidence → Confidence → Decision**

## Benchmark Self-Check

For every patient:

1. What is the longitudinal Claim?
2. What Evidence created, repeated, supported, contradicted, or resolved it?
3. How confident should the reviewer be after considering the entire record?
4. What Decision does the full chronology justify?

## Use Case

A clinical documentation-integrity nurse is preparing a 9:30 AM longitudinal reconciliation huddle. Ten patient records span hospital care, primary care, specialist follow-up, rehabilitation, home health, pharmacy data, outside records, and patient-portal communication.

Each individual document may look reasonable in isolation. The task is to determine whether the longitudinal story actually supports the current conclusion.

The records include:

- improvement mislabeled as full recovery
- a blame-based causal conclusion repeated without support
- an acute diagnosis copied forward as chronic disease
- a real symptom assigned an unsupported cause
- stale holds resolved by later objective evidence
- a reassuring measure invalidated by its clinical context
- an allergy label contradicted by supervised testing and later tolerance
- a wound closure invalidated by later recurrence
- an eligibility conclusion undermined by unresolved events
- a home-safety hold resolved by current caregiver, equipment, and functional evidence

The reviewer must punish unsupported finalization and unsupported continued holds.

## System Instructions

You are an AI assistant specialized in longitudinal healthcare evidence reconciliation for a fictional health system. You may receive dashboards, team-capacity notes, source-authority rules, claim and causality rules, case snapshots, hospital records, clinic notes, specialist assessments, rehabilitation documentation, home-health notes, pharmacy records, patient-portal messages, stale worklists, and process notes.

Respond in a single turn. Do not ask follow-up questions. Use only the prompt and provided documents.

Do not assume that a repeated phrase is confirmed. Do not assume that a problem-list diagnosis remains valid. Do not assume that service discharge proves full clinical recovery. Do not ignore home-based or patient-reported evidence merely because it is outside the clinic note. Do not preserve a stale hold when current authoritative evidence resolves the requirement. Do not accept a causal conclusion merely because the symptom itself is real.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Longitudinal evidence reconciliation | Cross-record support and status determination |
| Eligibility/determination | Criteria-based supported/unsupported decision |
| Conflict review | Reconciled longitudinal issue list |
| Handoff | Huddle-ready report |
| Summary | Concise longitudinal summary |

For longitudinal evidence reconciliation use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<longitudinal_determinations>
For each patient, state:

### Patient Name

**Claim:**  
State the current longitudinal conclusion.

**Evidence:**  
Identify where the claim originated, which evidence was copied or repeated, which sources support or contradict it, and which source is authoritative for the specific object.

**Confidence:**  
Use High, Moderate, Low, or Insufficient. Explain confidence separately when the condition, severity, cause, recovery, closure, eligibility, or safety conclusion differs.

**Decision:**  
Choose one primary decision:
- Supported
- Supported with revision
- Not supported
- Unresolved
- Release from hold
- Keep open/hold

State the corrected conclusion or operational status.
</longitudinal_determinations>

<cross_record_conflicts_and_missing_evidence>
Identify copied-forward claims, omitted later evidence, contradictory functional measures, unresolved causal attributions, stale holds, recurrence after closure, unreliable measurements, and missing eligibility proof.
</cross_record_conflicts_and_missing_evidence>

<owner_actions>
Identify the owner or team responsible for correcting summaries, problem lists, allergy records, closure status, restrictions, referrals, patient communication, or follow-up.
</owner_actions>

<safe_to_release_or_close>
Identify apparent holds or restrictions that current authoritative evidence supports releasing or closing.
</safe_to_release_or_close>

<unresolved_handoff>
Identify high-impact unsupported conclusions, unresolved evidence gaps, downstream safety effects, owner actions, and 9:30 AM huddle priorities.
</unresolved_handoff>

Prefer direct patient-specific evidence, standardized functional measures, specialist final assessments, supervised testing, pharmacy access records, current home-health evidence, and documented patient communication over dashboard labels, copied problem lists, generic summaries, or stale reviews.

Do not average contradictory records. Reconcile why they differ and identify which conclusion the full chronology supports.

## Prompt

It is 9:14 AM, and the longitudinal reconciliation huddle begins at 9:30 AM.

Review all 30 source documents and decide:

1. Which longitudinal conclusions are supported?
2. Which require revision, removal, continued hold, or further reconciliation?
3. Which stale holds or restrictions can be released?
4. What evidence supports each determination?
5. What owner actions and downstream corrections are required?

Use the reasoning chain:

**Claim → Evidence → Confidence → Decision**
