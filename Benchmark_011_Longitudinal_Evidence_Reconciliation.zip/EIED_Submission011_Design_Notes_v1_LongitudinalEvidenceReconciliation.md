# EIED Submission011 Design Notes v1

**Project:** Evidence Integrity & Eligibility Determination  
**Benchmark title:** Longitudinal Evidence Reconciliation  
**Primary reasoning objective:** Determine whether the full longitudinal record is sufficient, current, internally consistent, and authoritative enough to support the stated conclusion.  
**Required reasoning chain:** Claim → Evidence → Confidence → Decision

## Fictional Environment Convention

Each EIED benchmark is a standalone fictional environment. Repeated synthetic names do not indicate continuity across benchmarks.

---

## Why this domain?

Healthcare conclusions often become durable because they are repeated, not because they are revalidated.

A single encounter may look internally reasonable. The failure becomes visible only after reconciling:

- hospital documentation
- clinic follow-up
- specialist assessments
- rehabilitation measures
- pharmacy access records
- home-health observations
- outside records
- patient-portal reports

This benchmark asks:

> **Does the longitudinal record support the conclusion?**

The task is different from ordinary temporal integrity. Temporal integrity asks whether a later source supersedes an earlier one. Longitudinal reconciliation asks whether the entire sequence forms a coherent and evidentially supported story.

---

## What reasoning failures is this benchmark targeting?

The benchmark targets:

- treating repeated documentation as confirmation
- allowing a provisional or copied diagnosis to become permanent
- confusing medical stability with complete recovery
- confusing service discharge with clinical closure
- preserving blame-based causal conclusions despite systems evidence
- assigning a cause that does not fit the symptom chronology
- trusting a single contextually unreliable measure
- ignoring home-health or patient-reported recurrence
- treating an earlier accurate conclusion as permanently true
- keeping stale holds after current evidence resolves them
- using absence of witnessed events as proof of eligibility

---

## What shortcuts might an AI take?

Tempting shortcuts include:

- “The problem list says it in several notes.”
- “The discharge summary says recovered.”
- “The patient was discharged from home health, so all deficits resolved.”
- “The admission summary blamed nonadherence.”
- “The A1c is below seven, so diabetes is controlled.”
- “The allergy is longstanding, so it must be real.”
- “The wound clinic closed the episode.”
- “The EEG was negative, so the patient is seizure-free.”
- “The dashboard still says hold.”
- “The newest note automatically wins.”

---

## False-clean traps

### Avery Morgan
The record looks medically stable and repeatedly says recovered, but standardized functional evidence contradicts full recovery.

### Benjamin Cole
Multiple summaries attribute readmissions to nonadherence, but pharmacy, portal, and advanced-cardiology evidence support medication-access failure and progressive valve disease instead.

### Chloe Nguyen
An acute low estimated filtration rate becomes copied stage 4 CKD despite normal baseline and follow-up renal evidence.

### Dominic Hayes
A real symptom is assigned a post-COVID cause even though the symptom predates infection and an alternative cause is established.

### Gabriel Thomas
A reassuring A1c is treated as definitive despite recent transfusion and contradictory glucose-monitoring data.

### Isaac Rivera
A wound was accurately closed at one point, but later direct evidence shows recurrence while the dashboard remains closed.

### Jasmine Patel
A seizure-free summary and negative limited EEG are treated as enough for driving eligibility despite a possible intervening event.

---

## False-hold traps

### Emma Ross
An early home-health hold remains active after standardized functional goals, fall-free duration, and signed discharge evidence are complete.

### Hannah Lee
A remote unverified allergy label remains active despite negative supervised testing and later real-world tolerance.

### Kevin Brooks
An earlier home-discharge barrier remains active after function, caregiver support, equipment, and next-day services are all verified.

These cases prevent success through universal escalation or refusal to close.

---

## Longitudinal pattern distribution

| Pattern | Cases | Required reasoning |
|---|---|---|
| Improvement overstated as complete recovery | Avery | Preserve residual impairment |
| Repetition creates unsupported causality | Benjamin | Remove blame and reconcile systems evidence |
| Acute state copied as chronic disease | Chloe | Use baseline and specialist assessment |
| Symptom supported but cause unsupported | Dominic | Separate condition from attribution |
| Stale hold resolved by later objective evidence | Emma, Kevin | Release from hold |
| Contextually unreliable measure conflicts with trajectory | Gabriel | Reject single-value shortcut |
| Historical label disproven by definitive testing | Hannah | Remove stale restriction |
| Earlier valid closure invalidated by recurrence | Isaac | Reopen case |
| Eligibility interval undermined by unresolved event | Jasmine | Preserve hold and uncertainty |

---

## EIED pillars most heavily exercised

| Pillar | Strength | Notes |
|---|---:|---|
| Evidence Integrity | 10/10 | The conclusion must be earned from the entire sequence. |
| Eligibility Determination | 10/10 | Cases require support, revision, removal, closure, release, or hold decisions. |
| Documentation Consistency | 10/10 | Individually plausible records conflict across settings. |
| Temporal Integrity | 9/10 | Timing matters, but no single later-source rule solves the task. |
| Source Reliability | 10/10 | Functional tests, specialist assessments, pharmacy data, challenges, and home evidence have object-specific authority. |
| Missing Evidence | 9/10 | Driving eligibility and causal attribution remain unresolved when proof is absent. |
| Operational Readiness | 9/10 | Corrections affect closure, discharge, prescribing, monitoring, and restrictions. |
| Escalation Judgment | 10/10 | The model must correct unsafe conclusions without over-holding resolved cases. |

---

## Source-authority design

| Claim object | More authoritative evidence |
|---|---|
| Functional recovery | Standardized rehabilitation measures and direct functional observation |
| Medication adherence or access | Pharmacy authorization, fill, prescription, and portal records |
| Chronic kidney disease | Repeated outpatient renal values and nephrology assessment |
| Symptom causality | Symptom chronology, alternative-cause evaluation, and specialist assessment |
| Diabetes control | Valid longitudinal glucose evidence interpreted in transfusion/steroid context |
| Drug allergy | Supervised challenge and subsequent tolerance |
| Wound closure | Current direct measurement and home-based recurrence evidence |
| Seizure-free eligibility | Complete event history and neurologist adjudication |
| Home safety | Current functional testing, caregiver confirmation, equipment delivery, and service acceptance |

---

## Designer rationale

Longitudinal records create a distinctive type of false certainty.

No single document must be obviously wrong. Instead, the error emerges because:

- uncertainty becomes compressed
- preliminary language is copied
- later contradictory evidence is omitted
- status labels outlive the conditions that created them
- objective findings from other settings never reach the summary

This benchmark adds a whole-record reasoning layer to EIED.

It tests whether the model can answer:

> What does the record actually support after the entire story is reconciled?

It also preserves the suite’s balance: the model must correct unsupported conclusions without reflexively keeping every case open.
