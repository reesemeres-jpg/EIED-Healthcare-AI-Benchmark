# Submission002 Design Notes

**Project:** Evidence Integrity & Eligibility Determination  
**Benchmark title:** Prior Authorization Evidence Review  
**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.  
**Required reasoning chain:** Claim → Evidence → Confidence → Decision

---

## Why this domain?

Prior authorization is an ideal domain for this suite because it is explicitly evidence-driven. A request cannot be considered submission-ready just because a dashboard says “criteria met,” a provider wants it urgently, or a packet appears administratively complete. The evidence has to satisfy the payer criteria.

This domain also forces the model to reason across policy rules, date windows, diagnosis evidence, clinical exceptions, therapy history, medication safety requirements, DME documentation, and source authority.

The benchmark asks:

> Has the AI earned the right to submit, hold, or escalate this request?

---

## What reasoning failures is this benchmark targeting?

This benchmark targets several high-value AI failure modes:

- trusting queue labels such as “criteria met,” “renewal ready,” or “documentation complete”
- counting therapy for the wrong body region
- treating a prescribed medication as a completed medication trial
- missing pregnancy, active infection, safety lab, or date-window issues
- ignoring red-flag exceptions that bypass routine criteria
- treating DME delivery or supplier readiness as payer-criteria support
- holding cases based on stale scratchpads despite later authoritative addenda
- confusing administrative readiness with evidence-supported medical necessity

The goal is to test whether the model can apply criteria instead of repeating queue status.

---

## What shortcuts might an AI take?

Tempting shortcuts include:

- “The PA dashboard says criteria met, so submit.”
- “The request is urgent, so it must qualify.”
- “A medication was prescribed, so step therapy was completed.”
- “Any PT counts as conservative therapy.”
- “A low oxygen number qualifies, regardless of testing condition.”
- “A renewal is lower risk than a new request.”
- “A hold note means the request should stay on hold.”
- “A specialist addendum is just extra information, not potentially decisive evidence.”

The benchmark is built to punish those shortcuts.

---

## False-clean traps

These requests look ready or complete but should be held, corrected, or escalated:

- **Karen Mills:** Lumbar MRI marked criteria met, but PT was for cervical/shoulder issues and current lumbar symptoms are only 12 days old without red flags.
- **Rachel King:** GLP-1 PA marked criteria satisfied, but diagnosis, pregnancy status, pregnancy BMI, and step therapy are unsupported or conflicting.
- **Owen Blake:** Biologic renewal marked ready, but TB screen is expired, hepatitis panel is missing, and active infection concern is present.
- **Helen Brooks:** Home oxygen marked complete, but exertional desaturation was measured while already on oxygen, not room air.
- **Sasha Nguyen:** Migraine injectable marked step therapy complete, but topiramate was prescribed and never picked up.
- **Priya Shah:** DME marked ready, but wheelchair home usability and pressure cushion criteria are incomplete.
- **Devon Price:** Routine MRI marked ready, but urinary retention and saddle symptoms require clinical escalation rather than routine PA handling.

These cases test whether the AI validates the evidence behind “ready.”

---

## False-hold traps

These requests look blocked but should be released or submitted if the full source record is reviewed:

- **Alicia Gomez:** Hold says conservative therapy missing, but cancer history plus new focal night pain supports high-risk imaging exception.
- **Jonah Reed:** Initial hospital bed order looked weak, but later pulmonology addendum supports payer positioning criteria.

These cases punish the opposite failure mode: over-holding or over-escalating because the record looks messy.

---

## EIED pillars most heavily exercised

| Pillar | Strength | Notes |
|---|---:|---|
| Evidence Integrity | 10/10 | Queue labels and PA drafts must be validated against source criteria. |
| Eligibility Determination | 10/10 | The model must decide submit, hold, escalate, release, or defer. |
| Documentation Consistency | 9/10 | Requests, policies, notes, therapy records, pharmacy fills, and DME testing must be reconciled. |
| Temporal Integrity | 9/10 | Later addenda and newer safety information alter earlier PA conclusions. |
| Source Reliability | 10/10 | Current payer policy and later authoritative clinical documentation are central. |
| Missing Evidence | 10/10 | Missing safety labs, qualifying tests, therapy evidence, and criteria documentation drive decisions. |
| Operational Readiness | 8/10 | The PA huddle creates workflow pressure, but the central question is evidence-supported submission. |
| Escalation Judgment | 10/10 | The model must distinguish submit, hold, request info, clinical escalation, and release from hold. |

---

## Designer rationale

This benchmark expands the suite beyond discharge documentation into payer-facing medical necessity and eligibility reasoning. It exercises stricter criteria application and introduces more explicit source hierarchy: current policy beats old scratchpads, later addenda can resolve holds, and administrative queue status is not evidence.

It also strengthens the suite’s counterbalance principle. Alicia and Jonah make sure the model cannot simply escalate everything. To score well, the model has to be precise: hold unsupported requests, release supported requests, and escalate only when the evidence justifies escalation.
