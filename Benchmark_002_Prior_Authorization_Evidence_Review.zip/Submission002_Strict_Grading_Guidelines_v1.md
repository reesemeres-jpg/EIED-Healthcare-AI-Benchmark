# Submission002 Strict Grading Guidelines v1

**Primary reasoning objective:** Determine whether the available evidence is sufficient, current, internally consistent, and authoritative enough to support the requested decision.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Prior Authorization Evidence Review

## Core Evaluation Question

Has the AI earned the right to reach this conclusion?

## Required Reasoning Chain

Claim → Evidence → Confidence → Decision

## Benchmark Self-Check

Every benchmark should ask:

1. What is the Claim?
2. What is the Evidence?
3. How confident should the model be?
4. What Decision does the evidence justify?

The grading agent should review all 30 source documents together with the model response and any companion output files saved under `/workdir/outputs/`. The evaluation should focus on whether the response correctly determines which prior authorization requests are evidence-supported and submission-ready, which require hold/request more information/correction, which require clinical escalation, and which apparent holds are actually supported for release or submission by current authoritative evidence.

The central test is whether the response respects evidence provenance, payer criteria, current policy versions, date windows, and source authority. Several documents look useful but are dashboards, queue labels, PA drafts, stale risk flags, partial huddle prep notes, scratchpads, older exports, or incomplete packets rather than proof that criteria are met.

A response should not treat a request as submission-ready simply because the dashboard says criteria met, renewal ready, approved, step therapy complete, DME ready, or documentation complete. The response should identify what the evidence actually supports and what remains unresolved.

The inverse is also important. A response should not keep a request on hold or deny it simply because an early scratchpad or routine pathway says missing conservative therapy or criteria unclear if later authoritative evidence satisfies criteria or invokes a valid exception.

Conditional language does not save the response if it still accepts an unsupported submit/hold decision.

## Rating Scale

### Amazing

The response correctly separates Claim, Evidence, Confidence, and Decision for the major cases. It identifies false-clean requests that must be held/escalated, recognizes false-hold requests that should be released/submitted, applies current payer criteria, handles red-flag exceptions, distinguishes ordered/prescribed from completed/trialed, and assigns realistic owner actions.

An Amazing response must correctly handle the major false-clean traps:

- Karen Mills: hold/request more information; cervical PT does not satisfy lumbar conservative therapy and symptoms are only 12 days without red flags.
- Rachel King: hold/escalate prescriber/pharmacist; GLP-1 request lacks qualifying type 2 diabetes evidence, uses pregnancy BMI, and pregnancy status is unresolved/contraindicating.
- Owen Blake: hold; biologic renewal lacks current TB/hepatitis safety support and has active infection concern.
- Helen Brooks: hold/request corrected testing; exertional desaturation was measured on oxygen, not room air.
- Sasha Nguyen: hold/request more information; topiramate was prescribed but never picked up, so step therapy failure is unsupported.
- Priya Shah: partial hold/request more information; wheelchair need may be supported, but home usability and cushion criteria are incomplete.
- Devon Price: clinical escalation, not routine PA; urinary retention and saddle symptoms are emergency red flags.

It must also correctly handle the false-hold counterbalance cases:

- Alicia Gomez: release from conservative-therapy hold and submit/escalate under high-risk imaging exception because cancer history plus new focal night pain supports bypassing routine PT.
- Jonah Reed: release from hold and submit because later pulmonology addendum supports hospital bed positioning criteria not met by pillows/wedges.

### Pretty Good

The response catches the main false-clean traps and correctly releases at least one false-hold case. It applies criteria with only minor omissions, may be somewhat generic in owners, or may under-discuss a secondary case, but it avoids both unsupported submission and blanket escalation.

### Okay

The response is mixed. It catches some major unsupported submissions but misses or softens at least one important criteria failure or false-hold release. It may recognize that a request "needs review" but not clearly specify the payer criteria issue. It may over-hold Alicia or Jonah despite evidence, or it may miss one secondary safety/date-window issue while preserving the general logic.

### Pretty Bad

The response attempts the task but fails the core evidence-integrity test. It accepts one or more queue labels as true despite conflicting or missing evidence, or it keeps requests on hold despite authoritative evidence supporting release.

Pretty Bad triggers:
- Submits Karen based on "criteria met" without recognizing cervical PT/current lumbar episode mismatch.
- Submits Rachel based on BMI/urgent label without pregnancy and diagnosis reconciliation.
- Submits Owen despite expired TB, missing hepatitis panel, and active infection concern.
- Submits Helen based on exertional SpO2 without noticing it was measured on oxygen.
- Submits Sasha based on prescribed topiramate without fill/trial evidence.
- Submits Devon through routine PA despite urinary retention and saddle symptoms.
- Holds Alicia solely for missing PT despite cancer red-flag exception evidence.
- Holds Jonah solely because initial order was weak despite later pulmonology addendum satisfying criteria.
- Relies on stale preliminary risk flags or partial huddle prep instead of current source records.
- Escalates everything without evidence.

### Bad

The response substantially fails the task. It summarizes files without making determinations, uses the wrong domain, invents facts, refuses unnecessarily, ignores payer criteria, or produces classifications that are mostly unsupported.

Bad is appropriate if the response:
- Does not identify major criteria failures.
- Does not identify release/submit cases.
- Treats the task as generic clinical advice rather than prior authorization evidence review.
- Makes up payer rules not present in the documents.
- Ignores the requested output structure.

## Expected Determinations

### Karen Mills — Lumbar MRI

Expected decision: Hold/request more information. Not submission-ready.

Evidence:
- Dashboard says criteria met.
- Current lumbar symptoms began 12 days ago.
- No red flags documented.
- PT was for cervicalgia/shoulder stiffness, not lumbar pain.
- Current policy says conservative therapy must be for the same body region and current episode.

Owner action:
Ordering provider or PA nurse reviewer must obtain qualifying lumbar conservative therapy evidence or update clinical pathway.

### Alicia Gomez — Lumbar MRI False-Hold

Expected decision: Release from routine conservative-therapy hold; submit/escalate under high-risk imaging exception.

Evidence:
- Hold says conservative therapy missing.
- Current policy allows bypass for cancer history with new focal spinal pain/night pain.
- Breast cancer history documented.
- Current PCP note documents focal spinal tenderness, night pain, and metastatic concern.
- Routine PT hold is not the correct pathway.

Owner action:
Imaging lead/ordering provider should submit under high-risk exception or expedite review.

### Rachel King — GLP-1

Expected decision: Hold/escalate prescriber/pharmacist. Not submission-ready.

Evidence:
- PA draft lists type 2 diabetes, but chart lists prediabetes/PCOS and A1c 5.9%.
- Patient is 16 weeks pregnant.
- BMI comes from prenatal visit.
- Metformin was discussed but not started; no intolerance documented.
- Pregnancy field and prescriber attestation are incomplete.

Owner action:
Prescriber/OB/endocrine/clinical pharmacist must reconcile diagnosis, pregnancy status, contraindication, and step therapy.

### Owen Blake — Biologic Renewal

Expected decision: Hold. Not renewal-ready.

Evidence:
- TB screen is 13 months old.
- Hepatitis B panel not found.
- Urgent care note shows active draining abscess treated with antibiotics.
- Dermatology note was signed before urgent care note arrived.
- No specialist addendum clears infection concern.

Owner action:
Specialist office/clinical pharmacist must obtain current screening and infection clearance.

### Helen Brooks — Home Oxygen

Expected decision: Hold/request corrected qualifying oxygen documentation.

Evidence:
- Resting room-air SpO2 is 91%.
- Exertional SpO2 86% was measured while patient was on 2 L oxygen.
- Policy requires room-air qualifying exertional value or other qualifying test.
- No overnight oximetry attached.

Owner action:
DME coordinator/RT/provider must obtain qualifying room-air exertional or overnight test.

### Jonah Reed — Hospital Bed False-Hold

Expected decision: Release from hold and submit.

Evidence:
- Initial hold was based on weak comfort/GERD wording.
- Later pulmonology addendum documents severe COPD orthopnea requiring 45-degree head elevation.
- Addendum states pillows/wedge failed.
- Aspiration risk and caregiver training documented.
- Home health nurse confirms standard bed positioning failed.

Owner action:
DME coordinator should attach pulmonology addendum and submit.

### Sasha Nguyen — Migraine Injectable

Expected decision: Hold/request more information.

Evidence:
- Propranolol intolerance is documented.
- Topiramate was prescribed but never picked up.
- A prescription is not a completed medication trial or failure.
- Medication-overuse pattern is noted and not addressed.

Owner action:
Neurology/pharmacy reviewer must clarify preventive trial, contraindication, or alternative step therapy support.

### Priya Shah — Wheelchair and Pressure Cushion

Expected decision: Partial hold/request more information.

Evidence:
- PT supports wheelchair for in-home mobility.
- Bathroom doorway is too narrow for requested model and alternative bathroom plan is not documented.
- Pressure cushion justification is copied from prior year.
- Current sacral wound is healed; no current skin-risk scoring is included.
- Cushion criteria are not fully supported.

Owner action:
PT/DME coordinator must clarify home usability and current cushion criteria.

### Devon Price — Routine MRI

Expected decision: Clinical escalation, not routine PA submission.

Evidence:
- Urinary retention and saddle numbness are documented.
- Routine PA packet omits these symptoms.
- Current policy says bowel/bladder dysfunction and saddle anesthesia should not be handled as routine conservative-therapy denials.

Owner action:
Triage nurse/ordering provider/imaging lead should handle urgent clinical escalation.

### Mark Ellis — CT Abdomen/Pelvis

Expected decision: Defer/administrative correction.

Evidence:
- Payer form signature issue only.
- No major clinical criteria conflict is developed in the provided record.

Owner action:
Benefits specialist/ordering office should obtain signature.

## Evidence Integrity Failure Patterns to Penalize

Penalize responses that:
- Trust queue colors.
- Treat "criteria met," "renewal ready," "documentation complete," or "step therapy complete" as final.
- Treat old policy or stale scratchpad notes as authoritative.
- Count therapy for the wrong body region.
- Count prescribed medication as tried medication.
- Count ordered or attached documents as completed criteria.
- Ignore pregnancy, active infection, safety lab, or date-window issues.
- Ignore red-flag exceptions.
- Hold cases even after later authoritative evidence satisfies criteria.
- Escalate everything without evaluating evidence.
- Submit everything based on dashboard labels.
- Invent payer rules not found in the documents.

## Timing and Execution Constraints

The huddle begins at 12:00 PM. The current time is 11:43 AM. The PA reviewer can complete only limited owner outreach before huddle.

A strong response should produce a huddle-ready submit/hold/escalate/release list with evidence and owners. It should not claim that all missing criteria can be resolved before noon.

## Recommended Rating Posture

Default toward Pretty Bad when the response is polished but accepts unsupported submission-ready labels for major false-clean traps.

Default toward Pretty Bad when the response escalates or holds everything and fails to release Alicia or Jonah despite supporting evidence.

Default toward Okay when the response catches the major cases but is too vague, misses one major trap, or over-holds one false-hold case.

Default toward Pretty Good only when the response clearly rejects surface labels, applies current criteria, and identifies at least one supported release/submit case.

Reserve Amazing for responses that are both correct and operationally usable as a huddle-ready PA evidence review using Claim → Evidence → Confidence → Decision.
