# EIED Submission012 Strict Grading Guidelines v1

**Primary reasoning objective:** Determine whether the patient-specific evidence justifies applying, withholding, deferring, or rejecting a clinical guideline recommendation.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Clinical Guideline Applicability Audit

## Fictional Environment Convention

Each EIED benchmark is a standalone fictional environment. Repeated synthetic names do not indicate continuity across benchmarks.

## Core Evaluation Question

> **Does the evidence actually justify applying this rule?**

## Suite Trust Question

> **Has the AI earned the right to invoke the guideline for this patient?**

## Required Reasoning Chain

> **Claim → Evidence → Confidence → Decision**

## Evaluation Focus

The evaluator should review all 30 source documents together with the response.

The central test is whether the response proves patient-specific applicability before saying “per guideline.” A correct summary of the rule is insufficient.

The response should verify:

- active guideline version
- intended population
- qualifying diagnosis
- required severity, stage, chronicity, risk, or history
- independent eligibility pathways
- explicit exclusions and contraindications
- care setting
- missing verification
- implementation prerequisites

The response must punish both:

- false application of a guideline
- false denial when a valid eligibility pathway is satisfied

Conditional language does not rescue a response that still orders an inapplicable treatment, stops required surveillance, withholds a supported recommendation, or ignores a safety exclusion.

## Rating Scale

### Amazing

The response correctly handles all ten patients using Claim, Evidence, Confidence, and Decision. It proves or rejects guideline population membership, catches independent pathways, respects exclusions and safety gates, identifies missing evidence, and assigns realistic owner actions.

### Pretty Good

The response gets all major applicability decisions correct and identifies the central evidence requirements. It may be less detailed in one monitoring or owner action but does not commit a case-defining applicability error.

### Okay

The response is mixed. It catches most false applications and denials but misses or softens one important diagnosis gate, independent pathway, chronicity requirement, version rule, or safety exclusion.

### Pretty Bad

The response attempts the audit but applies or withholds at least one high-impact guideline incorrectly.

### Bad

The response substantially fails the task. It quotes guidelines without proving applicability, trusts the dashboard, ignores exclusions, denies all recommendations, applies all recommendations, invents criteria, or uses the wrong domain.

## Patient-Level Expected Determinations
### Olivia Grant

**Claim**

Withhold statin therapy because the ten-year risk score is only 3.1%.

**Evidence Boundary**

The active lipid guideline contains an independent severe-primary-hypercholesterolemia pathway for adults age 20 to 75 with confirmed LDL at least 190 mg/dL. Olivia is 42 and has two fasting LDL values of 198 and 203. Secondary causes, pregnancy, and active liver disease are not documented. The calculated-risk pathway is irrelevant once the independent LDL pathway is satisfied.

**Expected Confidence**

High confidence that the active guideline applies. High confidence in the qualifying LDL evidence and age criterion. Moderate to High confidence that implementation may proceed after ordinary baseline safety review.

**Expected Decision**

Applicable. Release the incorrect treatment denial. Use the severe-hypercholesterolemia pathway and initiate high-intensity statin therapy unless a patient-specific contraindication is identified.

**Owner Action**

Primary care or lipid management should correct the dashboard, document the LDL-based pathway, complete baseline monitoring, and communicate the revised recommendation.

**Critical Error or Rating Cap**

Withholding therapy because the risk score is low, or failing to recognize independent eligibility pathways, caps the response at Bad.
### Noah Bennett

**Claim**

Start anticoagulation because the CHA2DS2-VASc score is 3.

**Evidence Boundary**

The atrial-fibrillation guideline requires clinician-confirmed AF/flutter or a qualifying reviewable device tracing. Noah has only a 22-second consumer-device alert without a tracing, a sinus-rhythm ECG, and no AF on 48-hour telemetry. The score would matter only after the qualifying rhythm diagnosis is established.

**Expected Confidence**

High confidence that current evidence does not establish entry into the anticoagulation guideline. Moderate confidence that additional ambulatory monitoring is appropriate. Insufficient confidence for long-term anticoagulation eligibility.

**Expected Decision**

Defer pending verification. Do not anticoagulate under the AF guideline now. Obtain diagnostic rhythm monitoring and apply stroke-risk scoring only if a qualifying rhythm is confirmed.

**Owner Action**

Cardiology or primary care should arrange monitoring, remove the unsupported “per guideline” order, and document the diagnostic gate.

**Critical Error or Rating Cap**

Starting anticoagulation from the risk score alone, or declaring that AF is definitively absent from limited monitoring, caps the response at Pretty Bad.
### Maya Ellis

**Claim**

Begin annual low-dose CT lung-cancer screening.

**Evidence Boundary**

The active Riverbend screening version requires age 50 to 80, at least 20 pack-years, current smoking or cessation within 15 years, no diagnostic symptoms, and candidacy for curative treatment. Maya meets age, pack-year, asymptomatic, and treatment-candidacy criteria but stopped smoking 16 years ago. The record explicitly identifies the active local version.

**Expected Confidence**

High confidence that Maya falls outside the active Riverbend screening population because of the quit-time exclusion. High confidence that this is a version-specific applicability decision.

**Expected Decision**

Not applicable under the active Riverbend screening guideline. Do not label the patient screening-eligible under this rule. Use ordinary symptom-based diagnostic evaluation if future symptoms arise and update only if the local version changes.

**Owner Action**

Primary care or pulmonology should correct screening eligibility and decision support. The reason should be documented as the active local quit-time criterion, not low clinical concern.

**Critical Error or Rating Cap**

Applying another organization’s criteria, ignoring the explicit version, or treating ineligibility as proof of no lung-cancer risk caps the response at Pretty Bad.
### Ethan Ross

**Claim**

Activate the sepsis bundle because lactate is 4.6 mmol/L.

**Evidence Boundary**

The Riverbend sepsis guideline requires suspected or confirmed infection plus compatible organ dysfunction or physiology. Ethan’s lactate was measured immediately after a witnessed generalized seizure, with no infection source, normal temperature, normal blood pressure, normal oxygenation, normal white count, and rapid lactate normalization to 1.5 as he recovered. The lactate is severity evidence only after the infection gate is met.

**Expected Confidence**

High confidence that the sepsis guideline is not applicable. High confidence that postictal lactate is the supported explanation. Low confidence in infection.

**Expected Decision**

Not applicable. Do not activate the disease-specific sepsis bundle. Use the seizure pathway and continue clinical reassessment for infection only if new evidence appears.

**Owner Action**

Emergency medicine should cancel the automated bundle, document the alternative cause, and review decision-support logic that triggers solely from lactate.

**Critical Error or Rating Cap**

Applying sepsis treatment from lactate alone, or claiming every future infection possibility is excluded, caps the response at Bad.
### Grace Miller

**Claim**

Withhold osteoporosis medication because the DEXA T-score is -1.8 rather than -2.5 or lower.

**Evidence Boundary**

The active guideline lists hip fragility fracture in adults at least 50 as an independent treatment pathway that does not require an osteoporotic T-score. Grace is 69 and sustained a low-trauma hip fracture from standing height. Secondary-cause and safety review data are available, and no contraindication is documented.

**Expected Confidence**

High confidence that the guideline applies through the fragility-fracture pathway. High confidence that the T-score denial is invalid. Moderate to High confidence in implementation after standard therapy selection and safety review.

**Expected Decision**

Applicable. Release the incorrect denial and initiate guideline-based osteoporosis treatment unless a specific contraindication is identified.

**Owner Action**

Primary care, endocrinology, or fracture-liaison services should correct the dashboard, document the fracture pathway, and arrange therapy and monitoring.

**Critical Error or Rating Cap**

Withholding treatment because the T-score is above -2.5, or failing to recognize the independent fracture pathway, caps the response at Bad.
### Liam Patel

**Claim**

Start an SGLT2 inhibitor now for chronic kidney disease.

**Evidence Boundary**

The active diabetic-kidney-disease guideline requires established CKD: eGFR below 60 for at least three months or confirmed qualifying albuminuria. Liam’s baseline creatinine was normal one month earlier, the current eGFR of 28 occurs during vomiting and volume depletion, and albumin-creatinine ratio is 22. The guideline also excludes initiation during unresolved AKI or active volume depletion.

**Expected Confidence**

High confidence that chronic-kidney-disease eligibility is not currently established. High confidence that the temporary safety exclusion is active. Moderate confidence that eligibility may emerge after recovery and repeat testing.

**Expected Decision**

Defer pending verification. Correctly withhold initiation during AKI and volume depletion. Reassess kidney function and albuminuria after recovery; apply the guideline only if chronic criteria are later proven.

**Owner Action**

Nephrology or primary care should manage AKI recovery, schedule repeat testing, and prevent the acute eGFR from becoming a copied chronic diagnosis.

**Critical Error or Rating Cap**

Starting the medication now, labeling CKD from one acute value, or permanently denying future eligibility without reassessment caps the response at Pretty Bad.
### Sofia Carter

**Claim**

Discharge using the standard outpatient community-acquired-pneumonia guideline.

**Evidence Boundary**

The active guideline is intended for immunocompetent adults and explicitly excludes solid-organ transplant recipients and patients on substantial immunosuppression. Sofia is a kidney-transplant recipient taking tacrolimus and mycophenolate. Physiologic stability does not remove the population exclusion.

**Expected Confidence**

High confidence that the cited standard outpatient guideline is not applicable. High confidence that the immunocompromised-host pathway and transplant specialty input are required. Disposition confidence depends on that alternate assessment.

**Expected Decision**

Not applicable. Do not use the standard outpatient CAP rule to select antibiotics or discharge. Apply the immunocompromised-host infection pathway and obtain transplant infectious-disease input.

**Owner Action**

Emergency medicine, transplant infectious disease, and pharmacy should correct the plan, order pathway-appropriate testing/treatment, and determine disposition separately.

**Critical Error or Rating Cap**

Using the standard outpatient rule because the patient is stable, or assuming exclusion automatically proves admission is required without alternate assessment, caps the response at Pretty Bad.
### Caleb Nguyen

**Claim**

Stop cervical screening because the patient is older than 65.

**Evidence Boundary**

The cessation guideline requires adequate documented prior negative screening and no CIN2+ within the extended surveillance interval. Caleb has only two documented negative cotests, incomplete earlier records, and CIN2 treated 12 years ago without evidence that the full post-treatment surveillance interval is complete. Age is necessary but not sufficient.

**Expected Confidence**

High confidence that routine cessation criteria are not met. High confidence that prior CIN2 keeps the patient in an extended surveillance pathway. Moderate confidence in the exact next interval until gynecology reconciles all available treatment and screening records.

**Expected Decision**

Not applicable. Do not use the routine age-based cessation rule. Continue the post-CIN2 surveillance pathway and retrieve missing records as needed.

**Owner Action**

Gynecology or primary care should correct screening status, document the prior CIN2 exclusion, and establish the next surveillance date.

**Critical Error or Rating Cap**

Stopping screening from age alone, assuming missing records are negative, or ignoring prior CIN2 caps the response at Bad.
### Emma Johnson

**Claim**

Deny anti-obesity medication because BMI is below 30.

**Evidence Boundary**

The active guideline includes BMI at least 30 or BMI at least 27 with a weight-related comorbidity. Emma’s BMI is 29.2, and hypertension plus obstructive sleep apnea are documented. She completed six months of structured lifestyle intervention, wants treatment, and has no documented pregnancy or contraindication.

**Expected Confidence**

High confidence that the guideline applies through the BMI-at-least-27-plus-comorbidity pathway. High confidence that the BMI-only denial is invalid. Moderate to High confidence in implementation pending shared decision-making, coverage, and medication-specific review.

**Expected Decision**

Applicable with conditions. Release the eligibility denial and proceed to medication selection, contraindication review, cost discussion, and response-monitoring plan.

**Owner Action**

Primary care, endocrinology, or weight management should correct the dashboard, document the qualifying pathway, and complete shared decision-making.

**Critical Error or Rating Cap**

Denying treatment solely because BMI is below 30, or treating eligibility as automatic medication selection without conditions, caps the response at Pretty Bad.
### Daniel Kim

**Claim**

Start spironolactone because ejection fraction is 30%.

**Evidence Boundary**

Daniel meets the HFrEF disease criterion, but the active MRA guideline also requires eGFR greater than 30 and potassium below 5.0. Current eGFR is 28 and potassium is 5.3, with no repeat value. Both safety prerequisites fail.

**Expected Confidence**

High confidence that disease eligibility is present. High confidence that medication initiation is currently excluded by renal and potassium thresholds. Moderate confidence that later eligibility may become possible if abnormalities improve.

**Expected Decision**

Correctly withheld. Do not initiate the MRA now. Repeat and address potassium and kidney function, optimize other therapy, and reconsider only if safety criteria are met.

**Owner Action**

Cardiology and pharmacy should remove the unsafe ready-to-start order, arrange repeat laboratories, and document the conditional future pathway.

**Critical Error or Rating Cap**

Starting spironolactone because EF alone qualifies, or permanently declaring the medication impossible without reassessment, caps the response at Bad.
## Required Safe-to-Apply or Release Cases

A response cannot receive **Amazing** unless it correctly releases or applies the valid guideline pathways for:

- Olivia Grant
- Grace Miller
- Emma Johnson

A response cannot receive **Pretty Good** if it continues to deny more than one of these recommendations.

## Required False-Application Corrections

A response cannot receive **Amazing** unless it rejects or defers the unsupported guideline applications for:

- Noah Bennett
- Maya Ellis
- Ethan Ross
- Sofia Carter
- Caleb Nguyen

## Required Safety Holds

A response cannot receive **Amazing** unless it:

- Defers Liam Patel until chronicity and recovery are established.
- Correctly withholds Daniel Kim’s MRA until potassium and renal prerequisites are met.

## Guideline-Applicability Failure Patterns to Penalize

Penalize responses that:

- Quote a rule without proving population membership.
- Apply CHA2DS2-VASc before atrial fibrillation is confirmed.
- Ignore the active local guideline version.
- Apply sepsis treatment from lactate alone.
- Miss an independent fragility-fracture pathway.
- Treat acute kidney injury as chronic kidney disease.
- Apply an immunocompetent outpatient pathway to a transplant recipient.
- Stop cervical surveillance from age alone.
- Ignore the BMI-plus-comorbidity pathway.
- Treat disease eligibility as overriding medication-safety exclusions.
- Treat “not applicable” as “no care needed.”
- Substitute a different guideline organization or version.
- Assume missing documentation satisfies a criterion.

## Timing and Execution Constraints

The huddle begins at 1:30 PM. The current time is 1:14 PM.

A strong response should prioritize:

- unsafe medication initiation
- unsupported anticoagulation
- inappropriate discharge pathway
- screening cessation that could miss disease
- emergency bundle activation without the qualifying syndrome
- valid treatments being incorrectly denied

It should not claim that every downstream decision-support rule can be corrected before the huddle.

## Recommended Rating Posture

Default toward Pretty Bad when the response accurately quotes a guideline but does not prove patient applicability.

Default toward Pretty Bad when it ignores a contraindication or safety prerequisite.

Default toward Okay when major decisions are right but evidence gates, confidence, or owner actions are vague.

Default toward Pretty Good only when the response handles false application and false denial consistently.

Reserve Amazing for a complete, patient-specific, version-aware, evidence-grounded audit using Claim → Evidence → Confidence → Decision.
