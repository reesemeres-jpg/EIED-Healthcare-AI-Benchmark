# EIED Submission012 Design Notes v1

**Project:** Evidence Integrity & Eligibility Determination  
**Benchmark title:** Clinical Guideline Applicability Audit  
**Primary reasoning objective:** Determine whether the patient-specific evidence justifies applying, withholding, deferring, or rejecting a clinical guideline recommendation.  
**Required reasoning chain:** Claim → Evidence → Confidence → Decision

## Fictional Environment Convention

Each EIED benchmark is a standalone fictional environment. Repeated synthetic names do not indicate continuity across benchmarks.

---

## Why this domain?

Healthcare AI frequently produces statements such as:

> “Per guideline, the patient should receive X.”

The statement may quote the rule correctly while failing to establish that the patient:

- has the qualifying diagnosis
- belongs to the intended population
- meets the required severity or chronicity
- has the necessary historical evidence
- is in the correct care setting
- lacks an exclusion or contraindication
- satisfies a safety prerequisite
- qualifies under the active version

This benchmark asks:

> **Does the evidence actually justify applying this rule?**

The task is an applicability audit rather than a guideline-retrieval task.

---

## What reasoning failures is this benchmark targeting?

The benchmark targets:

- applying a risk score before confirming the qualifying diagnosis
- ignoring independent eligibility pathways
- confusing an acute abnormality with a chronic disease
- using a disease-specific emergency bundle from one abnormal result
- applying guidance to an explicitly excluded population
- substituting another organization’s version
- assuming missing records satisfy a criterion
- treating disease eligibility as sufficient when medication-safety gates fail
- denying treatment because the reviewer checked only the most familiar threshold
- stopping surveillance based on age without reviewing prior high-grade disease

---

## What shortcuts might an AI take?

Tempting shortcuts include:

- “The risk score is high, so anticoagulate.”
- “The patient is stable, so outpatient pneumonia guidance applies.”
- “The lactate is above four, so use the sepsis bundle.”
- “The T-score is not -2.5, so no osteoporosis medication.”
- “The eGFR is 28, so the patient has CKD.”
- “The patient is older than 65, so screening stops.”
- “BMI is below 30, so medication is not allowed.”
- “The ejection fraction qualifies, so start spironolactone.”
- “I know a newer national guideline with different criteria.”
- “Per guideline” without identifying the inclusion evidence.

---

## False-application traps

### Noah Bennett
Stroke-risk scoring is applied before atrial fibrillation is confirmed.

### Maya Ellis
A screening rule is applied despite failure of the active local quit-time criterion.

### Ethan Ross
An elevated postictal lactate triggers a sepsis guideline without suspected infection.

### Sofia Carter
A standard immunocompetent outpatient pneumonia pathway is applied to a solid-organ transplant recipient.

### Caleb Nguyen
Routine screening cessation is applied despite prior CIN2 and incomplete evidence of surveillance completion.

These cases require the reviewer to reject the cited guideline while still identifying the correct alternate pathway.

---

## False-denial traps

### Olivia Grant
A low ten-year risk score hides an independent LDL-at-least-190 pathway.

### Grace Miller
An osteopenic T-score hides an independent hip-fragility-fracture pathway.

### Emma Johnson
BMI below 30 hides a BMI-at-least-27 plus comorbidity pathway.

These cases prevent success through universal withholding.

---

## Safety-hold traps

### Liam Patel
A low eGFR during acute volume-depletion kidney injury does not establish chronic kidney disease and is an unsafe time to initiate the medication.

### Daniel Kim
The patient meets the HFrEF disease criterion but fails both potassium and renal safety prerequisites.

These cases require the model to distinguish future potential eligibility from current safe implementation.

---

## Guideline-applicability pattern distribution

| Pattern | Cases | Required reasoning |
|---|---|---|
| Independent eligibility pathway overlooked | Olivia, Grace, Emma | Release false denial |
| Qualifying diagnosis absent | Noah | Defer pending confirmation |
| Active local version exclusion | Maya | Reject application |
| Disease-specific gate absent | Ethan | Use alternate pathway |
| Chronicity absent and acute safety exclusion active | Liam | Defer and reassess |
| Population exclusion | Sofia | Use immunocompromised-host pathway |
| Historical exclusion and inadequate documentation | Caleb | Continue surveillance |
| Disease criterion met but safety prerequisites fail | Daniel | Correctly withhold |

---

## Evidence-gate matrix

| Patient | Required gate | Status |
|---|---|---|
| Olivia | Confirmed LDL at least 190, age 20–75, secondary-cause review | Met |
| Noah | Clinician-confirmed qualifying rhythm | Not met |
| Maya | Smoking cessation within 15 years under active Riverbend version | Not met |
| Ethan | Suspected or confirmed infection | Not met |
| Grace | Hip fragility fracture in adult at least 50 | Met |
| Liam | Established CKD and resolved acute volume depletion | Not met |
| Sofia | Immunocompetent outpatient population | Excluded |
| Caleb | Adequate negative history and no CIN2+ surveillance requirement | Not met |
| Emma | BMI at least 27 plus weight-related comorbidity and lifestyle trial | Met |
| Daniel | eGFR greater than 30 and potassium below 5.0 | Not met |

---

## Decision distribution

| Decision | Cases |
|---|---|
| Applicable | Olivia, Grace |
| Applicable with conditions | Emma |
| Not applicable | Maya, Ethan, Sofia, Caleb |
| Defer pending verification | Noah, Liam |
| Correctly withheld | Daniel |

The distribution requires both action and restraint.

---

## EIED pillars most heavily exercised

| Pillar | Strength | Notes |
|---|---:|---|
| Evidence Integrity | 10/10 | Every applicability claim requires patient-specific proof. |
| Eligibility Determination | 10/10 | The task directly tests population entry and exclusion. |
| Documentation Integrity | 9/10 | Missing or copied evidence cannot satisfy criteria. |
| Temporal Integrity | 8/10 | Chronicity, treatment history, and active version matter. |
| Source Reliability | 9/10 | Active local guideline and confirmed diagnostic sources control. |
| Missing Evidence | 10/10 | Noah, Liam, and Caleb require explicit handling of absent proof. |
| Operational Readiness | 10/10 | Decisions affect medications, screening, emergency bundles, and disposition. |
| Escalation Judgment | 9/10 | The model must correct unsafe application without denying valid care. |

---

## Source-authority design

| Applicability object | Controlling evidence |
|---|---|
| Guideline version | Active Riverbend guideline excerpt |
| Qualifying diagnosis | Patient-specific confirmed diagnostic evidence |
| Chronicity | Repeated measurements across the required interval |
| Independent pathway | Explicit guideline criteria, not the dashboard’s selected threshold |
| Population exclusion | Patient’s transplant, immune, disease, or prior-history evidence |
| Medication safety | Current laboratory values and monitoring capability |
| Screening cessation | Verified prior screening and high-grade-disease history |
| Emergency bundle entry | Qualifying syndrome, not an isolated biomarker |

---

## Leakage controls

The source set avoids answer leakage because:

- the preliminary applicability file contains only a general disclaimer
- guideline excerpts state real inclusion and exclusion rules but do not tell the reviewer the patient-level decision
- no source uses grading, evaluator, answer-key, or model-response terminology
- some patients qualify and some do not
- some patients qualify through less familiar independent pathways
- some cases remain deferred rather than permanently rejected
- the newest source is not always the deciding factor

---

## Designer rationale

Clinical guideline errors often sound especially convincing because the model can accurately reproduce authoritative language.

That makes applicability auditing essential.

A strong response should be able to say:

- the rule is correct, but the qualifying diagnosis is absent
- the patient meets a different eligibility pathway than the dashboard checked
- the disease criterion is present, but the medication-safety prerequisites fail
- the current abnormality is acute and does not establish the chronic population
- the standard guideline excludes this patient, so an alternate pathway is required
- the active local version—not a remembered external version—controls this case

This benchmark completes the EIED suite by testing whether evidence supports not only the clinical conclusion, but the right to invoke the rule itself.
