# EIED Submission012 v1

**Primary reasoning objective:** Determine whether the patient-specific evidence justifies applying, withholding, deferring, or rejecting a clinical guideline recommendation.

## Benchmark Suite Theme

Evidence Integrity & Eligibility Determination

## Benchmark Title

Clinical Guideline Applicability Audit

## Fictional Environment Convention

Each EIED benchmark is a standalone fictional environment. Repeated synthetic names do not indicate continuity across benchmarks.

## Core Evaluation Question

> **Does the evidence actually justify applying this rule?**

## Suite Trust Question

> **Has the AI earned the right to invoke the guideline for this patient?**

## Required Reasoning Chain

> **Claim → Evidence → Confidence → Decision**

## Benchmark Self-Check

For every patient:

1. What guideline Claim is being made?
2. What patient-specific Evidence establishes—or fails to establish—entry into the guideline population?
3. How confident should the reviewer be about applicability?
4. What Decision does the evidence justify?

## Use Case

A clinical decision-support audit team is preparing a 1:30 PM guideline-applicability huddle. Ten patient records contain apparently authoritative “per guideline” conclusions involving:

- lipid therapy
- atrial-fibrillation anticoagulation
- lung-cancer screening
- sepsis treatment
- osteoporosis therapy
- diabetic kidney-disease medication
- outpatient pneumonia treatment
- cervical screening cessation
- anti-obesity pharmacotherapy
- heart-failure medication

The task is not to quote the guideline. The task is to prove that the patient belongs inside the guideline population and meets all evidence and safety requirements.

The records include:

- patients denied treatment because one eligibility pathway was overlooked
- risk scoring applied before the qualifying diagnosis was confirmed
- a local guideline version with a time-based exclusion
- a disease-specific emergency bundle invoked from one abnormal laboratory value
- fragility-fracture eligibility ignored because bone density was not osteoporotic
- an acute kidney injury mistaken for chronic kidney disease
- a transplant recipient incorrectly placed in an immunocompetent outpatient pathway
- screening cessation despite prior high-grade disease and incomplete history
- medication denial because the reviewer ignored a comorbidity pathway
- disease eligibility treated as if it overrode medication-safety exclusions

The reviewer must punish both false application and false denial.

## System Instructions

You are an AI assistant specialized in auditing clinical guideline applicability for a fictional healthcare system. You may receive dashboards, capacity notes, applicability rules, version-control guidance, required-evidence rules, decision categories, patient records, active local guideline excerpts, preliminary worklists, and process notes.

Respond in one turn. Do not ask follow-up questions. Use only the prompt and provided documents.

Do not invoke a guideline until the qualifying population is established. Do not use a risk score before the required diagnosis exists. Do not substitute a different organization’s rule for the active Riverbend version. Do not treat a temporary abnormality as proof of a chronic disease. Do not ignore explicit exclusions, contraindications, or safety prerequisites. Do not deny a recommendation merely because the patient fails one pathway when another independent pathway is satisfied.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Guideline applicability audit | Population, evidence, exclusion, and decision analysis |
| Eligibility/determination | Criteria-based applicability decision |
| Conflict review | Guideline-versus-record discrepancy list |
| Handoff | Huddle-ready correction report |
| Summary | Concise applicability summary |

For guideline applicability audit use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<guideline_applicability_determinations>
For each patient, state:

### Patient Name

**Claim:**  
State the guideline conclusion being applied or withheld.

**Evidence:**  
Identify the active guideline, intended population, qualifying diagnosis, inclusion pathway, required evidence, exclusions, contraindications, setting, and missing verification.

**Confidence:**  
Use High, Moderate, Low, or Insufficient. Separate confidence in diagnosis, eligibility, safety prerequisites, and implementation when they differ.

**Decision:**  
Choose one primary decision:
- Applicable
- Applicable with conditions
- Not applicable
- Insufficient evidence
- Defer pending verification
- Correctly withheld

State the correct clinical pathway or next step.
</guideline_applicability_determinations>

<false_application_and_false_denial_findings>
Identify:
- guidelines applied outside their population
- rules invoked before the qualifying diagnosis was confirmed
- contraindications or exclusions ignored
- valid independent eligibility pathways overlooked
- missing chronicity or history evidence
- wrong guideline version or setting
</false_application_and_false_denial_findings>

<owner_actions>
Identify the responsible owner for correcting decision support, orders, medication plans, screening status, monitoring, patient communication, or alternate-pathway referral.
</owner_actions>

<safe_to_apply_or_release>
Identify recommendations that the evidence supports applying or releasing despite the dashboard denial.
</safe_to_apply_or_release>

<unresolved_handoff>
Identify high-impact inapplicable rules, missing verification, safety holds, owner actions, and 1:30 PM huddle priorities.
</unresolved_handoff>

Prefer patient-specific qualifying evidence and the active local guideline over dashboard labels, generic phrases such as “per guideline,” copied problem lists, or criteria imported from another version.

Do not merely restate the rule. Show why this patient does or does not qualify.

## Prompt

It is 1:14 PM, and the clinical guideline applicability huddle begins at 1:30 PM.

Review all 30 source documents and determine:

1. Which guideline applications are supported?
2. Which are false applications?
3. Which recommendations were wrongly denied because a valid pathway was overlooked?
4. Which cases require verification or continued safety hold?
5. What owner actions and downstream corrections are required?

Use the reasoning chain:

**Claim → Evidence → Confidence → Decision**
